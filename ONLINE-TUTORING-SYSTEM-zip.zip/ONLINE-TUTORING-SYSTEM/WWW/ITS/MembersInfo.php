<?php
/*********************************************************************************
 *       Filename: MembersInfo.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// MembersInfo CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// MembersInfo CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "MembersInfo.php";
//===============================


//===============================
// MembersInfo PageSecurity begin
check_security(2);
// MembersInfo PageSecurity end
//===============================

//===============================
// MembersInfo Open Event begin
// MembersInfo Open Event end
//===============================

//===============================
// MembersInfo OpenAnyPage Event start
// MembersInfo OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// MembersInfo Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sRecordErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Record":
    Record_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System ">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Record_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// MembersInfo Show end

//===============================
// MembersInfo Close Event begin
// MembersInfo Close Event end
//===============================
//********************************************************************************


//===============================
// Action of the Record Form
//-------------------------------
function Record_action($sAction)
{
//-------------------------------
// Initialize variables  
//-------------------------------
  global $db;
  
  global $sForm;
  global $sRecordErr;
  global $styles;
  $bExecSQL = true;
  $sActionFileName = "";
  $sWhere = "";
  $bErr = false;
  $pPKmember_id = "";
//-------------------------------

//-------------------------------
// Record Action begin
//-------------------------------
  $sActionFileName = "AdminMenu.php";

//-------------------------------
// Load all form fields into variables
//-------------------------------
//-------------------------------
// Record BeforeExecute Event begin
// Record BeforeExecute Event end
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  if(strlen($sRecordErr)) return;
  if($bExecSQL)
    $db->query($sSQL);
  header("Location: " . $sActionFileName);

//-------------------------------
// Record Action end
//-------------------------------
}

//===============================
// Display Record Form
//-------------------------------
function Record_show()
{
  global $db;
  
  global $sAction;
  global $sForm;
  global $sFileName;
  global $sRecordErr;
  global $styles;
  
  $fldmember_id = "";
  $fldmember_login = "";
  $fldmember_level = "";
  $fldname = "";
  $fldlast_name = "";
  $fldemail = "";
  $fldphone = "";
  $fldaddress = "";
  $fldnotes = "";
//-------------------------------
// Record Show begin
//-------------------------------
  $sFormTitle = "Intelligent Tutoring System - Member Info";
  $sWhere = "";
  $bPK = true;

?>
   
   <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
   <form method="POST" action="<?= $sFileName ?>" name="Record">
   <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
   <? if ($sRecordErr) { ?>
		<tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;" colspan="2"><font style="font-size: 11px; color: #000000"><?= $sRecordErr ?></font></td></tr>
	 <? } ?>
<? 

//-------------------------------
// Load primary key and form parameters
//-------------------------------
  if($sRecordErr == "")
  {
    $pmember_id = get_param("member_id");
  }
  else
  {
    $fldmember_id = strip(get_param("member_id"));
    $pmember_id = get_param("PK_member_id");
  }
//-------------------------------

//-------------------------------
// Load all form fields

//-------------------------------

//-------------------------------
// Build WHERE statement
//-------------------------------
  
  if( !strlen($pmember_id)) $bPK = false;
  
  $sWhere .= "member_id=" . tosql($pmember_id, "Number");
//-------------------------------
//-------------------------------
// Record Open Event begin
// Record Open Event end
//-------------------------------

//-------------------------------
// Build SQL statement and execute query
//-------------------------------
  $sSQL = "select * from members where " . $sWhere;
  // Execute SQL statement
  $db->query($sSQL);
  $bIsUpdateMode = ($bPK && !($sAction == "insert" && $sForm == "Record") && $db->next_record());
//-------------------------------

//-------------------------------
// Load all fields into variables from recordset or input parameters
//-------------------------------
  if($bIsUpdateMode)
  {
    $fldaddress = $db->f("address");
    $fldemail = $db->f("email");
    $fldname = $db->f("first_name");
    $fldlast_name = $db->f("last_name");
    $fldmember_id = $db->f("member_id");
    $fldmember_level = $db->f("member_level");
    $fldmember_login_URLLink = "MembersRecord.php";
    $fldmember_login_member_id = $db->f("member_id");
    $fldmember_login = $db->f("member_login");
    $fldnotes = $db->f("notes");
    $fldphone = $db->f("phone");
//-------------------------------
// Record ShowEdit Event begin
// Record ShowEdit Event end
//-------------------------------
  }
  else
  {
//-------------------------------
// Record ShowInsert Event begin
// Record ShowInsert Event end
//-------------------------------
  }
//-------------------------------
// Record Show Event begin
// Record Show Event end
//-------------------------------

//-------------------------------
// Show form field
//-------------------------------
    ?>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Login</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><a href="<?=$fldmember_login_URLLink?>?member_id=<?=$fldmember_login_member_id?>&<?= $transit_params ?>"><font style="font-size: 11px; color: #000000"><?=$fldmember_login?></font></a>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Level</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldmember_level) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">First Name</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldname) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Last Name</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldlast_name) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Email</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldemail) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Phone</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldphone) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Address</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldaddress) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Notes</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldnotes) ?>&nbsp;</font>
       </td>
     </tr>
    <tr><td colspan="2" align="right">

  <input type="hidden" name="FormName" value="Record">
  
  <input type="hidden" name="PK_member_id" value="<?= $pmember_id ?>">  
  <input type="hidden" name="member_id" value="<?= tohtml($fldmember_id)?>">
  </td></tr>
  </form>
  </table>
<?
  


//-------------------------------
// Record Close Event begin
// Record Close Event end
//-------------------------------

//-------------------------------
// Record Show end
//-------------------------------
}
//===============================
?>