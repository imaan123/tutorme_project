<?php
//********************************************************************************


//===============================
// Display Menu Form
//-------------------------------
function Menu_show()
{
  global $db;
  global $styles;
  $sFormTitle = "";

//-------------------------------
// Menu Open Event begin
// Menu Open Event end
//-------------------------------

//-------------------------------
// Set URLs
//-------------------------------
  $fldField2 = "index.php";
  $fldHome = "index.php";
  $fldReg = "Registration.php";
  $fldField1 = "Login.php";
  $fldAdmin = "AdminMenu.php";
//-------------------------------
// Menu Show begin
//-------------------------------


//-------------------------------
// Menu BeforeShow Event begin
// Menu BeforeShow Event end
//-------------------------------

//-------------------------------
// Show fields
//-------------------------------

?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField2?>"><font style="font-size: 11px; color: #000000"><img src="images/Logo_bookstore.gif" border="0"></font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldHome?>"><font style="font-size: 11px; color: #000000"><img src="images/icon_home.gif" border="0"></font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldReg?>"><font style="font-size: 11px; color: #000000"><img src="images/icon_reg.gif" border="0"></font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField1?>"><font style="font-size: 11px; color: #000000"><img src="images/icon_sign.gif" border="0"></font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldAdmin?>"><font style="font-size: 11px; color: #000000"><img src="images/icon_admin.gif" border="0"></font></a></td>
     </tr>
    </table>
<?php

//-------------------------------
// Menu Show end
//-------------------------------
}
//===============================

?>