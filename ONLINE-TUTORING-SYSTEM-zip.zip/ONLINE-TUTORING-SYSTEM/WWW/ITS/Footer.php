<?php
//********************************************************************************


//===============================
// Display Menu Form
//-------------------------------
function Footer_show()
{
  global $db;
  global $styles;
  $sFormTitle = "";

//-------------------------------
// Footer Open Event begin
// Footer Open Event end
//-------------------------------

//-------------------------------
// Set URLs
//-------------------------------
  $fldField1 = "index.php";
  $fldField3 = "Registration.php";
  $fldField2 = "Login.php";
  $fldField4 = "AdminMenu.php";
//-------------------------------
// Footer Show begin
//-------------------------------


//-------------------------------
// Footer BeforeShow Event begin
// Footer BeforeShow Event end
//-------------------------------

//-------------------------------
// Show fields
//-------------------------------

?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField1?>"><font style="font-size: 11px; color: #000000">Home</font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField3?>"><font style="font-size: 11px; color: #000000">SignUp</font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField2?>"><font style="font-size: 11px; color: #000000">SignIn</font></a></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField4?>"><font style="font-size: 11px; color: #000000">Admin</font></a></td>
     </tr>
    </table>
<?php

//-------------------------------
// Footer Show end
//-------------------------------
}
//===============================

?>