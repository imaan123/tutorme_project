quizname="Intelligent Tutoring System Quiz for Lesson 1 ENGLISH SUBJECT - GRAMMAR";
question[1]=new Array("Correct the Grammar: What is your name? ","Dog","Peter","Table","Pencil",2);
question[2]=new Array("Correct the Grammar: Where are you from? ","Fine Thank You!","Im Okay","Manila","Earth",3);
question[3]=new Array("Correct the Grammar: Excuse me what time is it? ","Monday","Tuesday","It's eight o'clock.","Friday",3);
question[4]=new Array("Correct the Grammar: What is your Surname (family name)? ","Narvasa","Maybe not!","How old?","Over there..",1);
question[5]=new Array("Correct the Grammar: What is your Fistname? ","Beginning","Walter","In Front","Finish",2);
question[6]=new Array("Correct the Grammar: Can i help you? ","Yes. Im looking for someone.","Your Father","Your Mother","In your house.",1);
question[7]=new Array("Correct the Grammar: What size are you? ","Good","Red","Blue","Large",4);
question[8]=new Array("Correct the Grammar: What is your Nationality? ","Brownish","Native","Black","Filipino",4);
question[9]=new Array("Correct the Grammar: Where can i find the supermarket? ","You haven't had a date since May.","Yes. There's one near here","Your pet monkey's run away. ","You have too many bills to pay.",2);
question[10]=new Array("Correct the Grammar: Is there a bank near this place?","Go","Stand Back","Yes. Over there!","You're Welcome",3);

