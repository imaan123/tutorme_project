quizname="Intelligent Tutoring System Quiz for Lesson 2 ENGLISH SUBJECT - SPELLING";
question[1]=new Array("Correct the spelling.. ","January","january","JanuarY","JANUary",1);
question[2]=new Array("Correct the spelling.. ","walter","WalteR","Walter","WaLter",3);
question[3]=new Array("Correct the spelling.. ","GenEral","General","geNeral","generaL",2);
question[4]=new Array("Correct the spelling.. ","mRs","mrs","mrS","Mrs",4);
question[5]=new Array("Correct the spelling.. ","FILipino","filipino","Filipino","filipinO",3);
question[6]=new Array("Correct the Final Consonants.. hit ","hitting","hitful","hitiest","hiting",1);
question[7]=new Array("Correct the Final Consonants.. travel ","travelful","traveliest","traveler","traveller",4);
question[8]=new Array("Correct the Final Consonants.. skim ","skimful","Skimming","skimiest","skiming",2);
question[9]=new Array("Correct the Final Consonants.. sad ","sading","sadful","sader","sadder",4);
question[10]=new Array("Correct the Final Consonants.. pop ","popful","popiest","popping","poping",3);

