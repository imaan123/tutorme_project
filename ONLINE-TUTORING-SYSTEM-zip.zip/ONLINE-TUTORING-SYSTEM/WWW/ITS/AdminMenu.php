<?php
/*********************************************************************************
 *       Filename: AdminMenu.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// AdminMenu CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// AdminMenu CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "AdminMenu.php";
//===============================


//===============================
// AdminMenu PageSecurity begin
check_security(2);
// AdminMenu PageSecurity end
//===============================

//===============================
// AdminMenu Open Event begin
// AdminMenu Open Event end
//===============================

//===============================
// AdminMenu OpenAnyPage Event start
// AdminMenu OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// AdminMenu Show begin

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Form_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// AdminMenu Show end

//===============================
// AdminMenu Close Event begin
// AdminMenu Close Event end
//===============================
//********************************************************************************


//===============================
// Display Menu Form
//-------------------------------
function Form_show()
{
  global $db;
  global $styles;
  $sFormTitle = "Intelligent Tutoring System - Administration Menu";

//-------------------------------
// Form Open Event begin
// Form Open Event end
//-------------------------------

//-------------------------------
// Set URLs
//-------------------------------
  $fldField1 = "MembersGrid.php";
  $fldField3 = "AdminTutorialLesson.php";
  $fldField4 = "CategoriesGrid.php";
//-------------------------------
// Form Show begin
//-------------------------------


//-------------------------------
// Form BeforeShow Event begin
// Form BeforeShow Event end
//-------------------------------

//-------------------------------
// Show fields
//-------------------------------

?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?= $sFormTitle ?></font></td>
     </tr>
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField1?>"><font style="font-size: 11px; color: #000000">Members Masterfile</font></a></td>
     </tr>
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField3?>"><font style="font-size: 11px; color: #000000">Tutorial Lesson Masterfile</font></a></td>
     </tr>
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField4?>"><font style="font-size: 11px; color: #000000">Categories Masterfile</font></a></td>
     </tr>
    </table>
<?php

//-------------------------------
// Form Show end
//-------------------------------
}
//===============================

?>