<?php
/*********************************************************************************
 *       Filename: TutorialLessonDetail.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// TutorialLessonDetail CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// TutorialLessonDetail CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "TutorialLessonDetail.php";
//===============================


//===============================
// TutorialLessonDetail PageSecurity begin
check_security(1);
// TutorialLessonDetail PageSecurity end
//===============================

//===============================
// TutorialLessonDetail Open Event begin
// TutorialLessonDetail Open Event end
//===============================

//===============================
// TutorialLessonDetail OpenAnyPage Event start
// TutorialLessonDetail OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// TutorialLessonDetail Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sDetailErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Detail":
    Detail_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Detail_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// TutorialLessonDetail Show end

//===============================
// TutorialLessonDetail Close Event begin
// TutorialLessonDetail Close Event end
//===============================
//********************************************************************************


//===============================
// Action of the Record Form
//-------------------------------
function Detail_action($sAction)
{
//-------------------------------
// Initialize variables  
//-------------------------------
  global $db;
  
  global $sForm;
  global $sDetailErr;
  global $styles;
  $bExecSQL = true;
  $sActionFileName = "";
  $sParams = "?";
  $sWhere = "";
  $bErr = false;
  $pPKitem_id = "";
  $fldproduct_url = "";
//-------------------------------

//-------------------------------
// Detail Action begin
//-------------------------------
  $sActionFileName = ".php";
  $sParams .= "item_id=" . urlencode(get_param("Trn_item_id"));

//-------------------------------
// Load all form fields into variables
//-------------------------------
  $fldproduct_url = get_param("product_url");
//-------------------------------
// Detail BeforeExecute Event begin
// Detail BeforeExecute Event end
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  if(strlen($sDetailErr)) return;
  if($bExecSQL)
    $db->query($sSQL);
  header("Location: " . $sActionFileName . $sParams);

//-------------------------------
// Detail Action end
//-------------------------------
}

//===============================
// Display Record Form
//-------------------------------
function Detail_show()
{
  global $db;
  
  global $sAction;
  global $sForm;
  global $sFileName;
  global $sDetailErr;
  global $styles;
  
  $flditem_id = "";
  $fldname = "";
  $fldauthor = "";
  $fldcategory_id = "";
  $fldimage_url = "";
  $fldnotes = "";
  $fldai = "";
  $fldquiz = "";
  $fldproduct_url = "";
//-------------------------------
// Detail Show begin
//-------------------------------
  $sFormTitle = "Intelligent Tutoring System - Lesson Proper";
  $sWhere = "";
  $bPK = true;

?>
   
   <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
   <form method="POST" action="<?= $sFileName ?>" name="Detail">
   <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
   <? if ($sDetailErr) { ?>
		<tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;" colspan="2"><font style="font-size: 11px; color: #000000"><?= $sDetailErr ?></font></td></tr>
	 <? } ?>
<? 

//-------------------------------
// Load primary key and form parameters
//-------------------------------
  if($sDetailErr == "")
  {
    $flditem_id = get_param("item_id");
    $trn_item_id = get_param("item_id");
    $pitem_id = get_param("item_id");
  }
  else
  {
    $flditem_id = strip(get_param("item_id"));
    $fldproduct_url = strip(get_param("product_url"));
    $trn_item_id = get_param("Trn_item_id");
    $pitem_id = get_param("PK_item_id");
  }
//-------------------------------

//-------------------------------
// Load all form fields

//-------------------------------

//-------------------------------
// Build WHERE statement
//-------------------------------
  
  if( !strlen($pitem_id)) $bPK = false;
  
  $sWhere .= "item_id=" . tosql($pitem_id, "Number");
//-------------------------------
//-------------------------------
// Detail Open Event begin
// Detail Open Event end
//-------------------------------

//-------------------------------
// Build SQL statement and execute query
//-------------------------------
  $sSQL = "select * from items where " . $sWhere;
  // Execute SQL statement
  $db->query($sSQL);
  $bIsUpdateMode = ($bPK && !($sAction == "insert" && $sForm == "Detail") && $db->next_record());
//-------------------------------

//-------------------------------
// Load all fields into variables from recordset or input parameters
//-------------------------------
  if($bIsUpdateMode)
  {
    $fldai_URLLink = $db->f("ai");
    $fldai = $db->f("ai");
    $fldauthor = $db->f("author");
    $fldcategory_id = $db->f("category_id");
    $fldimage_url_URLLink = $db->f("product_url");
    $fldimage_url = $db->f("image_url");
    $flditem_id = $db->f("item_id");
    $fldname = $db->f("name");
    $fldnotes = $db->f("notes");
    $fldproduct_url = $db->f("product_url");
    $fldquiz_URLLink = $db->f("quiz");
    $fldquiz = $db->f("quiz");
//-------------------------------
// Detail ShowEdit Event begin
// Detail ShowEdit Event end
//-------------------------------
  }
  else
  {
    if($sDetailErr == "")
    {
      $flditem_id = tohtml(get_param("item_id"));
    }
//-------------------------------
// Detail ShowInsert Event begin
// Detail ShowInsert Event end
//-------------------------------
  }
//-------------------------------
// Set lookup fields
//-------------------------------
  $fldcategory_id = get_db_value("SELECT name FROM categories WHERE category_id=" . tosql($fldcategory_id, "Number"));
  if($sDetailErr == "")
  {
//-------------------------------
// Detail Show Event begin
$fldimage_url="<img border=0 src=" . $fldimage_url . ">";
$fldai="CLICK THIS TO ACTIVATE ARTIFICIAL INTELLIGENCE LECTURER - PROFESSOR-X";
$fldquiz="CLICK THIS TO ACTIVATE QUIZ";
// Detail Show Event end
//-------------------------------
  }

//-------------------------------
// Show form field
//-------------------------------
    ?>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Topic</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldname) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Description</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldauthor) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Category</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= tohtml($fldcategory_id) ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Main Lesson</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><a href="<?=$fldimage_url_URLLink?>"><font style="font-size: 11px; color: #000000"><?=$fldimage_url?></font></a>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Notes/Trivia</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <?= $fldnotes ?>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Online Virtual Professor</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><a href="<?=$fldai_URLLink?>"><font style="font-size: 11px; color: #000000"><?=$fldai?></font></a>&nbsp;</font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Online Quiz</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><a href="<?=$fldquiz_URLLink?>"><font style="font-size: 11px; color: #000000"><?=$fldquiz?></font></a>&nbsp;</font>
       </td>
     </tr>
    <tr><td colspan="2" align="right">

  <input type="hidden" name="FormName" value="Detail">
  
  <input type="hidden" name="Trn_item_id" value="<?= $trn_item_id ?>">
  <input type="hidden" name="Rqd_item_id" value="<?= $rqd_item_id ?>";>
  <input type="hidden" name="PK_item_id" value="<?= $pitem_id ?>">  
  <input type="hidden" name="item_id" value="<?= tohtml($flditem_id)?>">
  <input type="hidden" name="product_url" value="<?= tohtml($fldproduct_url)?>">
  </td></tr>
  </form>
  </table>
<?
  


//-------------------------------
// Detail Close Event begin
// Detail Close Event end
//-------------------------------

//-------------------------------
// Detail Show end
//-------------------------------
}
//===============================
?>