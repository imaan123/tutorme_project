<?php
/*********************************************************************************
 *       Filename: TutorialLessonMaint.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// TutorialLessonMaint CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// TutorialLessonMaint CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "TutorialLessonMaint.php";
//===============================


//===============================
// TutorialLessonMaint PageSecurity begin
check_security(2);
// TutorialLessonMaint PageSecurity end
//===============================

//===============================
// TutorialLessonMaint Open Event begin
// TutorialLessonMaint Open Event end
//===============================

//===============================
// TutorialLessonMaint OpenAnyPage Event start
// TutorialLessonMaint OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// TutorialLessonMaint Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sBookErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Book":
    Book_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Book_show() ?>
    <SCRIPT Language="JavaScript">
if (document.forms["Book"])
document.Book.onsubmit=delconf;
function delconf() {
if (document.Book.FormAction.value == 'delete')
  return confirm('Delete record?');
}
</SCRIPT>
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// TutorialLessonMaint Show end

//===============================
// TutorialLessonMaint Close Event begin
// TutorialLessonMaint Close Event end
//===============================
//********************************************************************************


//===============================
// Action of the Record Form
//-------------------------------
function Book_action($sAction)
{
//-------------------------------
// Initialize variables  
//-------------------------------
  global $db;
  
  global $sForm;
  global $sBookErr;
  global $styles;
  $bExecSQL = true;
  $sActionFileName = "";
  $sParams = "?";
  $sWhere = "";
  $bErr = false;
  $pPKitem_id = "";
  $fldname = "";
  $fldauthor = "";
  $fldcategory_id = "";
  $fldproduct_url = "";
  $fldimage_url = "";
  $fldnotes = "";
  $fldai = "";
  $fldquiz = "";
  $fldis_recommended = "";
//-------------------------------

//-------------------------------
// Book Action begin
//-------------------------------
  $sActionFileName = "AdminTutorialLesson.php";
  $sParams .= "category_id=" . urlencode(get_param("Trn_category_id"));

//-------------------------------
// CANCEL action
//-------------------------------
  if($sAction == "cancel")
  {

//-------------------------------
// Book BeforeCancel Event begin
// Book BeforeCancel Event end
//-------------------------------
    header("Location: " . $sActionFileName . $sParams);
  }
//-------------------------------


//-------------------------------
// Build WHERE statement
//-------------------------------
  if($sAction == "update" || $sAction == "delete") 
  {
    $pPKitem_id = get_param("PK_item_id");
    if( !strlen($pPKitem_id)) return;
    $sWhere = "item_id=" . tosql($pPKitem_id, "Number");
  }
//-------------------------------


//-------------------------------
// Load all form fields into variables
//-------------------------------
  $fldname = get_param("name");
  $fldauthor = get_param("author");
  $fldcategory_id = get_param("category_id");
  $fldproduct_url = get_param("product_url");
  $fldimage_url = get_param("image_url");
  $fldnotes = get_param("notes");
  $fldai = get_param("ai");
  $fldquiz = get_param("quiz");
  $fldis_recommended = get_checkbox_value(get_param("is_recommended"), "1", "0", "Number");

//-------------------------------
// Validate fields
//-------------------------------
  if($sAction == "insert" || $sAction == "update") 
  {
    if(!strlen($fldname))
      $sBookErr .= "The value in field Topic is required.<br>";
    
    if(!strlen($fldcategory_id))
      $sBookErr .= "The value in field Category is required.<br>";
    
    if(!is_number($fldcategory_id))
      $sBookErr .= "The value in field Category is incorrect.<br>";
    
//-------------------------------
// Book Check Event begin
// Book Check Event end
//-------------------------------
    if(strlen($sBookErr)) return;
  }
//-------------------------------


//-------------------------------
// Create SQL statement
//-------------------------------
  switch(strtolower($sAction)) 
  {
    case "insert":
//-------------------------------
// Book Insert Event begin
// Book Insert Event end
//-------------------------------
        $sSQL = "insert into items (" . 
          "name," . 
          "author," . 
          "category_id," . 
          "product_url," . 
          "image_url," . 
          "notes," . 
          "ai," . 
          "quiz," . 
          "is_recommended)" . 
          " values (" . 
          tosql($fldname, "Text") . "," . 
          tosql($fldauthor, "Text") . "," . 
          tosql($fldcategory_id, "Number") . "," . 
          tosql($fldproduct_url, "Text") . "," . 
          tosql($fldimage_url, "Text") . "," . 
          tosql($fldnotes, "Text") . "," . 
          tosql($fldai, "Text") . "," . 
          tosql($fldquiz, "Text") . "," . 
          $fldis_recommended . 
          ")";
    break;
    case "update":

//-------------------------------
// Book Update Event begin
// Book Update Event end
//-------------------------------
        $sSQL = "update items set " .
          "name=" . tosql($fldname, "Text") .
          ",author=" . tosql($fldauthor, "Text") .
          ",category_id=" . tosql($fldcategory_id, "Number") .
          ",product_url=" . tosql($fldproduct_url, "Text") .
          ",image_url=" . tosql($fldimage_url, "Text") .
          ",notes=" . tosql($fldnotes, "Text") .
          ",ai=" . tosql($fldai, "Text") .
          ",quiz=" . tosql($fldquiz, "Text") .
          ",is_recommended=" . $fldis_recommended;
        $sSQL .= " where " . $sWhere;
    break;
    case "delete":
//-------------------------------
// Book Delete Event begin
// Book Delete Event end
//-------------------------------
        $sSQL = "delete from items where " . $sWhere;
    break;
  }
//-------------------------------
//-------------------------------
// Book BeforeExecute Event begin
// Book BeforeExecute Event end
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  if(strlen($sBookErr)) return;
  if($bExecSQL)
    $db->query($sSQL);
  header("Location: " . $sActionFileName . $sParams);

//-------------------------------
// Book Action end
//-------------------------------
}

//===============================
// Display Record Form
//-------------------------------
function Book_show()
{
  global $db;
  
  global $sAction;
  global $sForm;
  global $sFileName;
  global $sBookErr;
  global $styles;
  
  $flditem_id = "";
  $fldname = "";
  $fldauthor = "";
  $fldcategory_id = "";
  $fldproduct_url = "";
  $fldimage_url = "";
  $fldnotes = "";
  $fldai = "";
  $fldquiz = "";
  $fldis_recommended = "";
//-------------------------------
// Book Show begin
//-------------------------------
  $sFormTitle = "Intelligent Tutoring System - Tutorial Lessons";
  $sWhere = "";
  $bPK = true;

?>
   
   <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
   <form method="POST" action="<?= $sFileName ?>" name="Book">
   <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
   <? if ($sBookErr) { ?>
		<tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;" colspan="2"><font style="font-size: 11px; color: #000000"><?= $sBookErr ?></font></td></tr>
	 <? } ?>
<? 

//-------------------------------
// Load primary key and form parameters
//-------------------------------
  if($sBookErr == "")
  {
    $fldcategory_id = get_param("category_id");
    $flditem_id = get_param("item_id");
    $trn_category_id = get_param("category_id");
    $pitem_id = get_param("item_id");
  }
  else
  {
    $flditem_id = strip(get_param("item_id"));
    $fldname = strip(get_param("name"));
    $fldauthor = strip(get_param("author"));
    $fldcategory_id = strip(get_param("category_id"));
    $fldproduct_url = strip(get_param("product_url"));
    $fldimage_url = strip(get_param("image_url"));
    $fldnotes = strip(get_param("notes"));
    $fldai = strip(get_param("ai"));
    $fldquiz = strip(get_param("quiz"));
    $fldis_recommended = get_checkbox_value(get_param("is_recommended"), "1", "0", "Number");
    $trn_category_id = get_param("Trn_category_id");
    $pitem_id = get_param("PK_item_id");
  }
//-------------------------------

//-------------------------------
// Load all form fields

//-------------------------------

//-------------------------------
// Build WHERE statement
//-------------------------------
  
  if( !strlen($pitem_id)) $bPK = false;
  
  $sWhere .= "item_id=" . tosql($pitem_id, "Number");
//-------------------------------
//-------------------------------
// Book Open Event begin
// Book Open Event end
//-------------------------------

//-------------------------------
// Build SQL statement and execute query
//-------------------------------
  $sSQL = "select * from items where " . $sWhere;
  // Execute SQL statement
  $db->query($sSQL);
  $bIsUpdateMode = ($bPK && !($sAction == "insert" && $sForm == "Book") && $db->next_record());
//-------------------------------

//-------------------------------
// Load all fields into variables from recordset or input parameters
//-------------------------------
  if($bIsUpdateMode)
  {
    $flditem_id = $db->f("item_id");
//-------------------------------
// Load data from recordset when form displayed first time
//-------------------------------
    if($sBookErr == "") 
    {
      $fldname = $db->f("name");
      $fldauthor = $db->f("author");
      $fldcategory_id = $db->f("category_id");
      $fldproduct_url = $db->f("product_url");
      $fldimage_url = $db->f("image_url");
      $fldnotes = $db->f("notes");
      $fldai = $db->f("ai");
      $fldquiz = $db->f("quiz");
      $fldis_recommended = $db->f("is_recommended");
    }
//-------------------------------
// Book ShowEdit Event begin
// Book ShowEdit Event end
//-------------------------------
  }
  else
  {
    if($sBookErr == "")
    {
      $flditem_id = tohtml(get_param("item_id"));
      $fldcategory_id = tohtml(get_param("category_id"));
      $fldis_recommended= "0";
    }
//-------------------------------
// Book ShowInsert Event begin
// Book ShowInsert Event end
//-------------------------------
  }
//-------------------------------
// Book Show Event begin
// Book Show Event end
//-------------------------------

//-------------------------------
// Show form field
//-------------------------------
    ?>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Topic</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="name" maxlength="100" value="<?= tohtml($fldname) ?>" size="30" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Description</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="author" maxlength="100" value="<?= tohtml($fldauthor) ?>" size="30" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Category</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><select size="1" name="category_id">
<?
    $lookup_category_id = db_fill_array("select category_id, name from categories order by 2");

    if(is_array($lookup_category_id))
    {
      reset($lookup_category_id);
      while(list($key, $value) = each($lookup_category_id))
      {
        if($key == $fldcategory_id)
          $option="<option SELECTED value=\"$key\">$value";
        else 
          $option="<option value=\"$key\">$value";
        echo $option;
      }
    }
    
?></select></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Lesson Default Icon</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="product_url" maxlength="100" value="<?= tohtml($fldproduct_url) ?>" size="40" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Main Lesson</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="image_url" maxlength="100" value="<?= tohtml($fldimage_url) ?>" size="40" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Notes/Trivia</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><textarea name="notes" cols="60" rows="8"><?=tohtml($fldnotes)?></textarea></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Online Virtual Tutor</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="ai" maxlength="255" value="<?= tohtml($fldai) ?>" size="40" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Online Quiz</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="quiz" maxlength="255" value="<?= tohtml($fldquiz) ?>" size="40" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Recommended</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000">
      <? if(strtolower($fldis_recommended) == strtolower("1")) { ?>
        <input CHECKED type="checkbox" name="is_recommended">
      <? } else {?>
        <input type="checkbox" name="is_recommended">
      <? } ?>
</font>
       </td>
     </tr>
    <tr><td colspan="2" align="right">
<? if (!$bIsUpdateMode) { ?>
   <input type="hidden" value="insert" name="FormAction">
   <input type="submit" value="Add" onclick="document.Book.FormAction.value = 'insert';">
<? } ?>
<? if ($bIsUpdateMode) { ?>
  <input type="hidden" value="update" name="FormAction"/>
  <input type="submit" value="Update" onclick="document.Book.FormAction.value = 'update';">
  <input type="submit" value="Delete" onclick="document.Book.FormAction.value = 'delete';">
<? } ?>
  <input type="submit" value="Cancel" onclick="document.Book.FormAction.value = 'cancel';">
  <input type="hidden" name="FormName" value="Book">
  
  <input type="hidden" name="Trn_category_id" value="<?= $trn_category_id ?>">
  <input type="hidden" name="PK_item_id" value="<?= $pitem_id ?>">  
  <input type="hidden" name="item_id" value="<?= tohtml($flditem_id)?>">
  </td></tr>
  </form>
  </table>
<?
  


//-------------------------------
// Book Close Event begin
// Book Close Event end
//-------------------------------

//-------------------------------
// Book Show end
//-------------------------------
}
//===============================
?>