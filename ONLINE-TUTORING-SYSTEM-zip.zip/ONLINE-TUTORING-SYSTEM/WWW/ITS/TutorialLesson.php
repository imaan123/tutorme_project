<?php
/*********************************************************************************
 *       Filename: TutorialLesson.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// TutorialLesson CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// TutorialLesson CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "TutorialLesson.php";
//===============================


//===============================
// TutorialLesson PageSecurity begin
// TutorialLesson PageSecurity end
//===============================

//===============================
// TutorialLesson Open Event begin
// TutorialLesson Open Event end
//===============================

//===============================
// TutorialLesson OpenAnyPage Event start
// TutorialLesson OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// TutorialLesson Show begin

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Search_show() ?>
    
   </td>
   <td valign="top">
<?php AdvMenu_show() ?>
    
   </td>
  </tr>
 </table>
 <table>
  <tr>
   <td valign="top">
<?php Total_show() ?>
    
   </td>
  </tr>
 </table>
 <table>
  <tr>
   <td valign="top">
<?php Results_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// TutorialLesson Show end

//===============================
// TutorialLesson Close Event begin
// TutorialLesson Close Event end
//===============================
//********************************************************************************


//===============================
// Display Grid Form
//-------------------------------
function Results_show()
{
//-------------------------------
// Initialize variables  
//-------------------------------
  
  
  global $db;
  global $sResultsErr;
  global $sFileName;
  global $styles;
  $sWhere = "";
  $sOrder = "";
  $sSQL = "";
  $sFormTitle = "Tutorial Lesson Search Results";
  $HasParam = false;
  $iRecordsPerPage = 2;
  $iCounter = 0;
  $iPage = 0;
  $bEof = false;
  $iSort = "";
  $iSorted = "";
  $sDirection = "";
  $sSortParams = "";

  $transit_params = "author=" . tourl(get_param("author")) . "&category_id=" . tourl(get_param("category_id")) . "&name=" . tourl(get_param("name")) . "&pricemax=" . tourl(get_param("pricemax")) . "&pricemin=" . tourl(get_param("pricemin")) . "&";
  $form_params = "author=" . tourl(get_param("author")) . "&category_id=" . tourl(get_param("category_id")) . "&name=" . tourl(get_param("name")) . "&pricemax=" . tourl(get_param("pricemax")) . "&pricemin=" . tourl(get_param("pricemin")) . "&";

//-------------------------------
// Build ORDER BY statement
//-------------------------------
  $sOrder = " order by i.name Asc";
  $iSort = get_param("FormResults_Sorting");
  $iSorted = get_param("FormResults_Sorted");
  if(!$iSort)
  {
    $form_sorting = "";
  }
  else
  {
    if($iSort == $iSorted)
    {
      $form_sorting = "";
      $sDirection = " DESC";
      $sSortParams = "FormResults_Sorting=" . $iSort . "&FormResults_Sorted=" . $iSort . "&";
    }
    else
    {
      $form_sorting = $iSort;
      $sDirection = " ASC";
      $sSortParams = "FormResults_Sorting=" . $iSort . "&FormResults_Sorted=" . "&";
    }
    if ($iSort == 1) $sOrder = " order by i.name" . $sDirection;
    if ($iSort == 2) $sOrder = " order by i.author" . $sDirection;
    if ($iSort == 3) $sOrder = " order by c.name" . $sDirection;
  }

//-------------------------------
// HTML column headers
//-------------------------------
?>
     <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="1"><a name="Results"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
      </tr>
<?
  
//-------------------------------
// Build WHERE statement
//-------------------------------
  $pauthor = get_param("author");

  if(strlen($pauthor))
  {
    $HasParam = true;
    $sWhere = $sWhere . "i.author like " . tosql("%".$pauthor ."%", "Text");
  }
  $pcategory_id = get_param("category_id");
  if(is_number($pcategory_id) && strlen($pcategory_id))
    $pcategory_id = tosql($pcategory_id, "Number");
  else 
    $pcategory_id = "";

  if(strlen($pcategory_id))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.category_id=" . $pcategory_id;
  }
  $pname = get_param("name");

  if(strlen($pname))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.name like " . tosql("%".$pname ."%", "Text");
  }
  $ppricemax = get_param("pricemax");
  if(is_number($ppricemax) && strlen($ppricemax))
    $ppricemax = tosql($ppricemax, "Number");
  else 
    $ppricemax = "";

  if(strlen($ppricemax))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.price<" . $ppricemax;
  }
  $ppricemin = get_param("pricemin");
  if(is_number($ppricemin) && strlen($ppricemin))
    $ppricemin = tosql($ppricemin, "Number");
  else 
    $ppricemin = "";

  if(strlen($ppricemin))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.price>" . $ppricemin;
  }


  if($HasParam)
    $sWhere = " AND (" . $sWhere . ")";


//-------------------------------
// Build base SQL statement
//-------------------------------
  $sSQL = "select i.author as i_author, " . 
    "i.category_id as i_category_id, " . 
    "i.item_id as i_item_id, " . 
    "i.name as i_name, " . 
    "i.price as i_price, " . 
    "i.product_url as i_product_url, " . 
    "c.category_id as c_category_id, " . 
    "c.name as c_name " . 
    " from items i, categories c" . 
    " where c.category_id=i.category_id  ";
//-------------------------------

//-------------------------------
// Results Open Event begin
// Results Open Event end
//-------------------------------

//-------------------------------
// Assemble full SQL statement
//-------------------------------
  $sSQL .= $sWhere . $sOrder;
//-------------------------------

  

//-------------------------------
// Execute SQL statement
//-------------------------------
  $db->query($sSQL);
  $next_record = $db->next_record();
//-------------------------------
// Process empty recordset
//-------------------------------
  if(!$next_record)
  {
?>
     <tr>
      <td colspan="3" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">No records</font></td>
     </tr>
<?
 
//-------------------------------
//  The insert link.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">
<?
  
?>
  </table>
<?

    return;
  }

//-------------------------------

//-------------------------------
// Initialize page counter and records per page
//-------------------------------
  $iRecordsPerPage = 2;
  $iCounter = 0;
//-------------------------------

//-------------------------------
// Process page scroller
//-------------------------------
  $iPage = get_param("FormResults_Page");
  if(!strlen($iPage)) $iPage = 1; else $iPage = intval($iPage);

  if(($iPage - 1) * $iRecordsPerPage != 0)
  {
    do
    {
      $iCounter++;
    } while ($iCounter < ($iPage - 1) * $iRecordsPerPage && $db->next_record());
    $next_record = $db->next_record();
  }

  $iCounter = 0;
//-------------------------------

//-------------------------------
// Display grid based on recordset
//-------------------------------
  while($next_record  && $iCounter < $iRecordsPerPage)
  {
//-------------------------------
// Create field variables based on database fields
//-------------------------------
    $fldauthor = $db->f("i_author");
    $fldcategory_id = $db->f("c_name");
    $fldname_URLLink = "TutorialLessonDetail.php";
    $fldname_item_id = $db->f("i_item_id");
    $fldname = $db->f("i_name");
    $fldproduct_url = $db->f("i_product_url");
    $next_record = $db->next_record();
    
//-------------------------------
// Results Show begin
//-------------------------------

//-------------------------------
// Results Show Event begin
$fldname = "<img border=\"0\" src=\"" . $fldproduct_url . "\"></td><td valign=\"top\" width=\"100%\"><table><tr><td style=\"background-color: #FFFFFF; border-style: inset; border-width: 0\"><font style=\"font-size: 10pt; color: #CE7E00; font-weight: bold\"><b>" . $fldname . "</b>";
// Results Show Event end
//-------------------------------


//-------------------------------
// Process the HTML controls
//-------------------------------
?>      <tr><td><table width="100%" style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></td>
      </tr>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"><a href="<?=$fldname_URLLink?>?item_id=<?=$fldname_item_id?>&<?= $transit_params ?>"><font style="font-size: 11px; color: #000000"><?=$fldname?></font></a>&nbsp;</font></td>
      </tr>
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></td>
      </tr>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">
      <?= tohtml($fldauthor) ?>&nbsp;</font></td>
      </tr>
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Category</font></td>
      </tr>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">
      <?= tohtml($fldcategory_id) ?>&nbsp;</font></td>
      </tr></table></td>
</tr>
</table>
</td></tr><?

//-------------------------------
// Process the record separator
//-------------------------------
    if($next_record  || $iCounter == $iRecordsPerPage - 1)
    {
?>
      <tr>
       <td colspan="1" style="background-color: #FFFFFF; border-width: 1">&nbsp;</td>
      </tr>
<?
    }
//-------------------------------
//-------------------------------
// Results Show end
//-------------------------------

//-------------------------------
// Move to the next record and increase record counter
//-------------------------------
    
    $iCounter++;
  }

 
//-------------------------------
//  Grid. The insert link and record navigator.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">
<?
  
  // Results Navigation begin
  $bEof = $next_record;
  if($bEof || $iPage != 1)
  {
    if ($iPage == 1) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font>
<? }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormResults_Page=<?=$iPage - 1?>#Results"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font></a>
<?
    }
    echo "&nbsp;[&nbsp;" . $iPage . "&nbsp;]&nbsp;";
    
    if (!$bEof) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font>
<?
    }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormResults_Page=<?=$iPage + 1?>#Results"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font></a>
<?
    }
  }

//-------------------------------
// Results Navigation end
//-------------------------------

//-------------------------------
// Finish form processing
//-------------------------------
  ?>
      </font></td></tr>
    </table>
  <?


//-------------------------------
// Results Close Event begin
// Results Close Event end
//-------------------------------
}
//===============================


//===============================
// Display Search Form
//-------------------------------
function Search_show()
{
  global $db;
  global $styles;
  
  global $sForm;
  $sFormTitle = "Tutorial Lesson Search";
  $sActionFileName = "TutorialLesson.php";
  $scategory_idDisplayValue = "All";

//-------------------------------
// Search Open Event begin
// Search Open Event end
//-------------------------------
//-------------------------------
// Set variables with search parameters
//-------------------------------
  $fldcategory_id = strip(get_param("category_id"));
  $fldname = strip(get_param("name"));

//-------------------------------
// Search Show begin
//-------------------------------


//-------------------------------
// Search Show Event begin
// Search Show Event end
//-------------------------------
?>
    <form method="GET" action="<?= $sActionFileName ?>" name="Search">
    <input type="hidden" name="FormName" value="Search"><input type="hidden" name="FormAction" value="search">
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="5"><a name="Search"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
     </tr>
     <tr>
      <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Category</font></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><select size="1" name="category_id">
<?
    echo "<option value=\"\">" . $scategory_idDisplayValue . "</option>";
    $lookup_category_id = db_fill_array("select category_id, name from categories order by 2");

    if(is_array($lookup_category_id))
    {
      reset($lookup_category_id);
      while(list($key, $value) = each($lookup_category_id))
      {
        if($key == $fldcategory_id)
          $option="<option SELECTED value=\"$key\">$value";
        else 
          $option="<option value=\"$key\">$value";
        echo $option;
      }
    }
    
?></select></td>
     </tr>
     <tr>
      <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Topic</font></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><input type="text" name="name" maxlength="10" value="<?= tohtml($fldname) ?>" size="10" ></td>
     </tr>
     <tr>
     <td align="right" colspan="3"><input type="submit" value="Search"></td>
    </tr>
   </table>
   </form>
<?

//-------------------------------
// Search Show end
//-------------------------------

//-------------------------------
// Search Close Event begin
// Search Close Event end
//-------------------------------
//===============================
}


//===============================
// Display Menu Form
//-------------------------------
function AdvMenu_show()
{
  global $db;
  global $styles;
  $sFormTitle = "Advanced Tutorial Search";

//-------------------------------
// AdvMenu Open Event begin
// AdvMenu Open Event end
//-------------------------------

//-------------------------------
// Set URLs
//-------------------------------
  $fldField1 = "AdvSearch.php";
//-------------------------------
// AdvMenu Show begin
//-------------------------------


//-------------------------------
// AdvMenu BeforeShow Event begin
// AdvMenu BeforeShow Event end
//-------------------------------

//-------------------------------
// Show fields
//-------------------------------

?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td colspan="1"  style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?= $sFormTitle ?></font></td>
     </tr>
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField1?>"><font style="font-size: 11px; color: #000000">Advanced Search</font></a></td>
     </tr>
    </table>
<?php

//-------------------------------
// AdvMenu Show end
//-------------------------------
}
//===============================


//===============================
// Display Grid Form
//-------------------------------
function Total_show()
{
//-------------------------------
// Initialize variables  
//-------------------------------
  
  
  global $db;
  global $sTotalErr;
  global $sFileName;
  global $styles;
  $sWhere = "";
  $sOrder = "";
  $sSQL = "";
  $sFormTitle = "";
  $HasParam = false;
  $iRecordsPerPage = 20;
  $iCounter = 0;

  $transit_params = "";
  $form_params = "author=" . tourl(get_param("author")) . "&category_id=" . tourl(get_param("category_id")) . "&name=" . tourl(get_param("name")) . "&pricemax=" . tourl(get_param("pricemax")) . "&pricemin=" . tourl(get_param("pricemin")) . "&";

//-------------------------------
// HTML column headers
//-------------------------------
?>
     <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
<?
  
//-------------------------------
// Build WHERE statement
//-------------------------------
  $pauthor = get_param("author");

  if(strlen($pauthor))
  {
    $HasParam = true;
    $sWhere = $sWhere . "i.author like " . tosql("%".$pauthor ."%", "Text");
  }
  $pcategory_id = get_param("category_id");
  if(is_number($pcategory_id) && strlen($pcategory_id))
    $pcategory_id = tosql($pcategory_id, "Number");
  else 
    $pcategory_id = "";

  if(strlen($pcategory_id))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.category_id=" . $pcategory_id;
  }
  $pname = get_param("name");

  if(strlen($pname))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.name like " . tosql("%".$pname ."%", "Text");
  }
  $ppricemax = get_param("pricemax");
  if(is_number($ppricemax) && strlen($ppricemax))
    $ppricemax = tosql($ppricemax, "Number");
  else 
    $ppricemax = "";

  if(strlen($ppricemax))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.price<=" . $ppricemax;
  }
  $ppricemin = get_param("pricemin");
  if(is_number($ppricemin) && strlen($ppricemin))
    $ppricemin = tosql($ppricemin, "Number");
  else 
    $ppricemin = "";

  if(strlen($ppricemin))
  {
    if($sWhere != "") 
      $sWhere .= " and ";
    $HasParam = true;
    $sWhere = $sWhere . "i.price>=" . $ppricemin;
  }


  if($HasParam)
    $sWhere = " WHERE (" . $sWhere . ")";


//-------------------------------
// Build base SQL statement
//-------------------------------
  $sSQL = "select i.author as i_author, " . 
    "i.category_id as i_category_id, " . 
    "i.item_id as i_item_id, " . 
    "i.name as i_name, " . 
    "i.price as i_price " . 
    " from items i ";
//-------------------------------

//-------------------------------
// Total Open Event begin
$sSQL="select count(item_id) as i_item_id from items as i";
// Total Open Event end
//-------------------------------

//-------------------------------
// Assemble full SQL statement
//-------------------------------
  $sSQL .= $sWhere . $sOrder;
//-------------------------------

  

//-------------------------------
// Execute SQL statement
//-------------------------------
  $db->query($sSQL);
  $next_record = $db->next_record();
//-------------------------------
// Process empty recordset
//-------------------------------
  if(!$next_record)
  {
?>
     <tr>
      <td colspan="1" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">No records</font></td>
     </tr>
<?
   
?>
  </table>
<?

    return;
  }

//-------------------------------

//-------------------------------
// Initialize page counter and records per page
//-------------------------------
  $iRecordsPerPage = 20;
  $iCounter = 0;
//-------------------------------

//-------------------------------
// Display grid based on recordset
//-------------------------------
  while($next_record  && $iCounter < $iRecordsPerPage)
  {
//-------------------------------
// Create field variables based on database fields
//-------------------------------
    $flditem_id = $db->f("i_item_id");
    $next_record = $db->next_record();
    
//-------------------------------
// Total Show begin
//-------------------------------

//-------------------------------
// Total Show Event begin
// Total Show Event end
//-------------------------------


//-------------------------------
// Process the HTML controls
//-------------------------------
?>
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Items found:</font></td><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">
      <?= tohtml($flditem_id) ?>&nbsp;</font></td>
      </tr><?

//-------------------------------
// Process the record separator
//-------------------------------
    if($next_record  || $iCounter == $iRecordsPerPage - 1)
    {
?>
      <tr>
       <td colspan="2" style="background-color: #FFFFFF; border-width: 1">&nbsp;</td>
      </tr>
<?
    }
//-------------------------------
//-------------------------------
// Total Show end
//-------------------------------

//-------------------------------
// Move to the next record and increase record counter
//-------------------------------
    
    $iCounter++;
  }

 

//-------------------------------
// Finish form processing
//-------------------------------
  ?>
    </table>
  <?


//-------------------------------
// Total Close Event begin
// Total Close Event end
//-------------------------------
}
//===============================

?>