<?php
/*********************************************************************************
 *       Filename: CategoriesRecord.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// CategoriesRecord CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// CategoriesRecord CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "CategoriesRecord.php";
//===============================


//===============================
// CategoriesRecord PageSecurity begin
check_security(2);
// CategoriesRecord PageSecurity end
//===============================

//===============================
// CategoriesRecord Open Event begin
// CategoriesRecord Open Event end
//===============================

//===============================
// CategoriesRecord OpenAnyPage Event start
// CategoriesRecord OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// CategoriesRecord Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sCategoriesErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Categories":
    Categories_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Categories_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// CategoriesRecord Show end

//===============================
// CategoriesRecord Close Event begin
// CategoriesRecord Close Event end
//===============================
//********************************************************************************


//===============================
// Action of the Record Form
//-------------------------------
function Categories_action($sAction)
{
//-------------------------------
// Initialize variables  
//-------------------------------
  global $db;
  
  global $sForm;
  global $sCategoriesErr;
  global $styles;
  $bExecSQL = true;
  $sActionFileName = "";
  $sWhere = "";
  $bErr = false;
  $pPKcategory_id = "";
  $fldname = "";
//-------------------------------

//-------------------------------
// Categories Action begin
//-------------------------------
  $sActionFileName = "CategoriesGrid.php";

//-------------------------------
// CANCEL action
//-------------------------------
  if($sAction == "cancel")
  {

//-------------------------------
// Categories BeforeCancel Event begin
// Categories BeforeCancel Event end
//-------------------------------
    header("Location: " . $sActionFileName);
  }
//-------------------------------


//-------------------------------
// Build WHERE statement
//-------------------------------
  if($sAction == "update" || $sAction == "delete") 
  {
    $pPKcategory_id = get_param("PK_category_id");
    if( !strlen($pPKcategory_id)) return;
    $sWhere = "category_id=" . tosql($pPKcategory_id, "Number");
  }
//-------------------------------


//-------------------------------
// Load all form fields into variables
//-------------------------------
  $fldname = get_param("name");

//-------------------------------
// Validate fields
//-------------------------------
  if($sAction == "insert" || $sAction == "update") 
  {
    if(!strlen($fldname))
      $sCategoriesErr .= "The value in field Name is required.<br>";
    
//-------------------------------
// Categories Check Event begin
// Categories Check Event end
//-------------------------------
    if(strlen($sCategoriesErr)) return;
  }
//-------------------------------


//-------------------------------
// Create SQL statement
//-------------------------------
  switch(strtolower($sAction)) 
  {
    case "insert":
//-------------------------------
// Categories Insert Event begin
// Categories Insert Event end
//-------------------------------
        $sSQL = "insert into categories (" . 
          "name)" . 
          " values (" . 
          tosql($fldname, "Text") . 
          ")";
    break;
    case "update":

//-------------------------------
// Categories Update Event begin
// Categories Update Event end
//-------------------------------
        $sSQL = "update categories set " .
          "name=" . tosql($fldname, "Text");
        $sSQL .= " where " . $sWhere;
    break;
    case "delete":
//-------------------------------
// Categories Delete Event begin
// Categories Delete Event end
//-------------------------------
        $sSQL = "delete from categories where " . $sWhere;
    break;
  }
//-------------------------------
//-------------------------------
// Categories BeforeExecute Event begin
// Categories BeforeExecute Event end
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  if(strlen($sCategoriesErr)) return;
  if($bExecSQL)
    $db->query($sSQL);
  header("Location: " . $sActionFileName);

//-------------------------------
// Categories Action end
//-------------------------------
}

//===============================
// Display Record Form
//-------------------------------
function Categories_show()
{
  global $db;
  
  global $sAction;
  global $sForm;
  global $sFileName;
  global $sCategoriesErr;
  global $styles;
  
  $fldcategory_id = "";
  $fldname = "";
//-------------------------------
// Categories Show begin
//-------------------------------
  $sFormTitle = "Intelligent Tutoring System - Categories Masterfile";
  $sWhere = "";
  $bPK = true;

?>
   
   <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
   <form method="POST" action="<?= $sFileName ?>" name="Categories">
   <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
   <? if ($sCategoriesErr) { ?>
		<tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;" colspan="2"><font style="font-size: 11px; color: #000000"><?= $sCategoriesErr ?></font></td></tr>
	 <? } ?>
<? 

//-------------------------------
// Load primary key and form parameters
//-------------------------------
  if($sCategoriesErr == "")
  {
    $fldcategory_id = get_param("category_id");
    $pcategory_id = get_param("category_id");
  }
  else
  {
    $fldcategory_id = strip(get_param("category_id"));
    $fldname = strip(get_param("name"));
    $pcategory_id = get_param("PK_category_id");
  }
//-------------------------------

//-------------------------------
// Load all form fields

//-------------------------------

//-------------------------------
// Build WHERE statement
//-------------------------------
  
  if( !strlen($pcategory_id)) $bPK = false;
  
  $sWhere .= "category_id=" . tosql($pcategory_id, "Number");
//-------------------------------
//-------------------------------
// Categories Open Event begin
// Categories Open Event end
//-------------------------------

//-------------------------------
// Build SQL statement and execute query
//-------------------------------
  $sSQL = "select * from categories where " . $sWhere;
  // Execute SQL statement
  $db->query($sSQL);
  $bIsUpdateMode = ($bPK && !($sAction == "insert" && $sForm == "Categories") && $db->next_record());
//-------------------------------

//-------------------------------
// Load all fields into variables from recordset or input parameters
//-------------------------------
  if($bIsUpdateMode)
  {
    $fldcategory_id = $db->f("category_id");
//-------------------------------
// Load data from recordset when form displayed first time
//-------------------------------
    if($sCategoriesErr == "") 
    {
      $fldname = $db->f("name");
    }
//-------------------------------
// Categories ShowEdit Event begin
// Categories ShowEdit Event end
//-------------------------------
  }
  else
  {
    if($sCategoriesErr == "")
    {
      $fldcategory_id = tohtml(get_param("category_id"));
    }
//-------------------------------
// Categories ShowInsert Event begin
// Categories ShowInsert Event end
//-------------------------------
  }
//-------------------------------
// Categories Show Event begin
// Categories Show Event end
//-------------------------------

//-------------------------------
// Show form field
//-------------------------------
    ?>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Name</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="name" maxlength="50" value="<?= tohtml($fldname) ?>" size="50" ></font>
       </td>
     </tr>
    <tr><td colspan="2" align="right">
<? if (!$bIsUpdateMode) { ?>
   <input type="hidden" value="insert" name="FormAction">
   <input type="submit" value="Insert" onclick="document.Categories.FormAction.value = 'insert';">
<? } ?>
<? if ($bIsUpdateMode) { ?>
  <input type="hidden" value="update" name="FormAction"/>
  <input type="submit" value="Update" onclick="document.Categories.FormAction.value = 'update';">
  <input type="submit" value="Delete" onclick="document.Categories.FormAction.value = 'delete';">
<? } ?>
  <input type="submit" value="Cancel" onclick="document.Categories.FormAction.value = 'cancel';">
  <input type="hidden" name="FormName" value="Categories">
  
  <input type="hidden" name="PK_category_id" value="<?= $pcategory_id ?>">  
  <input type="hidden" name="category_id" value="<?= tohtml($fldcategory_id)?>">
  </td></tr>
  </form>
  </table>
<?
  


//-------------------------------
// Categories Close Event begin
// Categories Close Event end
//-------------------------------

//-------------------------------
// Categories Show end
//-------------------------------
}
//===============================
?>