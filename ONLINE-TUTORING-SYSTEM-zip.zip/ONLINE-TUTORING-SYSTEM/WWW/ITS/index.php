<?php
/*********************************************************************************
 *       Filename: index.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// index CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// index CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "index.php";
//===============================


//===============================
// index PageSecurity begin
// index PageSecurity end
//===============================

//===============================
// index Open Event begin
// index Open Event end
//===============================

//===============================
// index OpenAnyPage Event start
// index OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// index Show begin

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   <td valign="top">
<?php SearchLesson_show() ?>
    
<?php AdvMenu_show() ?>
    <br>
<?php Categories_show() ?>
    <br></td>
   <td valign="top"><table width="250"><tr><td></td></tr></table>
<?php RecommendedLessons_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// index Show end

//===============================
// index Close Event begin
// index Close Event end
//===============================
//********************************************************************************


//===============================
// Display Search Form
//-------------------------------
function SearchLesson_show()
{
  global $db;
  global $styles;
  
  global $sForm;
  $sFormTitle = "Search Tutorial Lesson";
  $sActionFileName = "TutorialLesson.php";
  $scategory_idDisplayValue = "All";

//-------------------------------
// SearchLesson Open Event begin
// SearchLesson Open Event end
//-------------------------------
//-------------------------------
// Set variables with search parameters
//-------------------------------
  $fldcategory_id = strip(get_param("category_id"));
  $fldname = strip(get_param("name"));

//-------------------------------
// SearchLesson Show begin
//-------------------------------


//-------------------------------
// SearchLesson Show Event begin
// SearchLesson Show Event end
//-------------------------------
?>
    <form method="GET" action="<?= $sActionFileName ?>" name="SearchLesson">
    <input type="hidden" name="FormName" value="SearchLesson"><input type="hidden" name="FormAction" value="search">
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="5"><a name="SearchLesson"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
     </tr>
     <tr>
      <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Category</font></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><select size="1" name="category_id">
<?
    echo "<option value=\"\">" . $scategory_idDisplayValue . "</option>";
    $lookup_category_id = db_fill_array("select category_id, name from categories order by 2");

    if(is_array($lookup_category_id))
    {
      reset($lookup_category_id);
      while(list($key, $value) = each($lookup_category_id))
      {
        if($key == $fldcategory_id)
          $option="<option SELECTED value=\"$key\">$value";
        else 
          $option="<option value=\"$key\">$value";
        echo $option;
      }
    }
    
?></select></td>
     </tr>
     <tr>
      <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Topic</font></td>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><input type="text" name="name" maxlength="10" value="<?= tohtml($fldname) ?>" size="10" ></td>
     </tr>
     <tr>
     <td align="right" colspan="3"><input type="submit" value="Search"></td>
    </tr>
   </table>
   </form>
<?

//-------------------------------
// SearchLesson Show end
//-------------------------------

//-------------------------------
// SearchLesson Close Event begin
// SearchLesson Close Event end
//-------------------------------
//===============================
}


//===============================
// Display Menu Form
//-------------------------------
function AdvMenu_show()
{
  global $db;
  global $styles;
  $sFormTitle = "Advanced Lesson Search";

//-------------------------------
// AdvMenu Open Event begin
// AdvMenu Open Event end
//-------------------------------

//-------------------------------
// Set URLs
//-------------------------------
  $fldField1 = "AdvSearch.php";
//-------------------------------
// AdvMenu Show begin
//-------------------------------


//-------------------------------
// AdvMenu BeforeShow Event begin
// AdvMenu BeforeShow Event end
//-------------------------------

//-------------------------------
// Show fields
//-------------------------------

?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
     <tr>
      <td colspan="1"  style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?= $sFormTitle ?></font></td>
     </tr>
     <tr>
      <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $fldField1?>"><font style="font-size: 11px; color: #000000">Advanced search</font></a></td>
     </tr>
    </table>
<?php

//-------------------------------
// AdvMenu Show end
//-------------------------------
}
//===============================


//===============================
// Display Grid Form
//-------------------------------
function RecommendedLessons_show()
{
//-------------------------------
// Initialize variables  
//-------------------------------
  
  
  global $db;
  global $sRecommendedLessonsErr;
  global $sFileName;
  global $styles;
  $sWhere = "";
  $sOrder = "";
  $sSQL = "";
  $sFormTitle = "Intelligent Tutoring System - Recommended Lessons";
  $HasParam = false;
  $iRecordsPerPage = 3;
  $iCounter = 0;
  $iPage = 0;
  $bEof = false;
  $iSort = "";
  $iSorted = "";
  $sDirection = "";
  $sSortParams = "";
  $iTmpI = 0;
  $iTmpJ = 0;
  $sCountSQL = "";

  $transit_params = "";
  $form_params = "";

//-------------------------------
// Build ORDER BY statement
//-------------------------------
  $iSort = get_param("FormRecommendedLessons_Sorting");
  $iSorted = get_param("FormRecommendedLessons_Sorted");
  if(!$iSort)
  {
    $form_sorting = "";
  }
  else
  {
    if($iSort == $iSorted)
    {
      $form_sorting = "";
      $sDirection = " DESC";
      $sSortParams = "FormRecommendedLessons_Sorting=" . $iSort . "&FormRecommendedLessons_Sorted=" . $iSort . "&";
    }
    else
    {
      $form_sorting = $iSort;
      $sDirection = " ASC";
      $sSortParams = "FormRecommendedLessons_Sorting=" . $iSort . "&FormRecommendedLessons_Sorted=" . "&";
    }
    if ($iSort == 1) $sOrder = " order by i.name" . $sDirection;
    if ($iSort == 2) $sOrder = " order by i.author" . $sDirection;
  }

//-------------------------------
// HTML column headers
//-------------------------------
?>
     <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="1"><a name="RecommendedLessons"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
      </tr>
<?


  $sWhere = " WHERE is_recommended=1";


//-------------------------------
// Build base SQL statement
//-------------------------------
  $sSQL = "select i.author as i_author, " . 
    "i.item_id as i_item_id, " . 
    "i.name as i_name, " . 
    "i.product_url as i_product_url " . 
    " from items i ";
//-------------------------------

//-------------------------------
// RecommendedLessons Open Event begin
// RecommendedLessons Open Event end
//-------------------------------

//-------------------------------
// Assemble full SQL statement
//-------------------------------
  $sSQL .= $sWhere . $sOrder;
  if($sCountSQL == "")
  {
    $iTmpI = strpos(strtolower($sSQL), "select");
    $iTmpJ = strpos(strtolower($sSQL), "from") - 1;
    $sCountSQL = str_replace(substr($sSQL, $iTmpI + 6, $iTmpJ - $iTmpI - 6), " count(*) ", $sSQL);
    $iTmpI = strpos(strtolower($sCountSQL), "order by");
    if($iTmpI > 1) 
      $sCountSQL = substr($sCountSQL, 0, $iTmpI - 1);
  }
//-------------------------------

  

//-------------------------------
// Execute SQL statement
//-------------------------------
  $db->query($sSQL);
  $next_record = $db->next_record();
//-------------------------------
// Process empty recordset
//-------------------------------
  if(!$next_record)
  {
?>
     <tr>
      <td colspan="2" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">No records</font></td>
     </tr>
<?
 
//-------------------------------
//  The insert link.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">
<?
  
?>
  </table>
<?

    return;
  }

//-------------------------------

//-------------------------------
// Initialize page counter and records per page
//-------------------------------
  $iRecordsPerPage = 3;
  $iCounter = 0;
//-------------------------------

//-------------------------------
// Process page scroller
//-------------------------------
  $iPage = get_param("FormRecommendedLessons_Page");
  $db_count = get_db_value($sCountSQL);
  $dResult = intval($db_count) / $iRecordsPerPage;
  $iPageCount = intval($dResult);
  if($iPageCount < $dResult) $iPageCount = $iPageCount + 1;
  $iTotalPages = $iPageCount;

  
  if(!strlen($iPage))
    $iPage = 1;
  else
  {
    if($iPage == "last") $iPage = $iPageCount;
  }

  if(($iPage - 1) * $iRecordsPerPage != 0)
  {
    do
    {
      $iCounter++;
    } while ($iCounter < ($iPage - 1) * $iRecordsPerPage && $db->next_record());
    $next_record = $db->next_record();
  }

  $iCounter = 0;
//-------------------------------

//-------------------------------
// Display grid based on recordset
//-------------------------------
  while($next_record  && $iCounter < $iRecordsPerPage)
  {
//-------------------------------
// Create field variables based on database fields
//-------------------------------
    $fldauthor = $db->f("i_author");
    $fldname_URLLink = "TutorialLessonDetail.php";
    $fldname_item_id = $db->f("i_item_id");
    $fldname = $db->f("i_name");
    $fldproduct_url = $db->f("i_product_url");
    $next_record = $db->next_record();
    
//-------------------------------
// RecommendedLessons Show begin
//-------------------------------

//-------------------------------
// RecommendedLessons Show Event begin
$fldname = "<img border=\"0\" src=\"" . $fldproduct_url . "\"></td><td valign=\"top\"><table width=\"100%\" style=\"width:100%\"><tr><td style=\"background-color: #FFFFFF; border-style: inset; border-width: 0\"><font style=\"font-size: 10pt; color: #CE7E00; font-weight: bold\"><b>" . $fldname . "</b>";
// RecommendedLessons Show Event end
//-------------------------------


//-------------------------------
// Process the HTML controls
//-------------------------------
?>      <tr><td><table width="100%" style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></td>
      </tr>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"><a href="<?=$fldname_URLLink?>?item_id=<?=$fldname_item_id?>&<?= $transit_params ?>"><font style="font-size: 11px; color: #000000"><?=$fldname?></font></a>&nbsp;</font></td>
      </tr>
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></td>
      </tr>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">
      <?= tohtml($fldauthor) ?>&nbsp;</font></td>
      </tr></table></td>
</tr>
</table>
</td></tr><?

//-------------------------------
// Process the record separator
//-------------------------------
    if($next_record  || $iCounter == $iRecordsPerPage - 1)
    {
?>
      <tr>
       <td colspan="1" style="background-color: #FFFFFF; border-width: 1">&nbsp;</td>
      </tr>
<?
    }
//-------------------------------
//-------------------------------
// RecommendedLessons Show end
//-------------------------------

//-------------------------------
// Move to the next record and increase record counter
//-------------------------------
    
    $iCounter++;
  }

 
//-------------------------------
//  Grid. The insert link and record navigator.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">
<?
  
  // RecommendedLessons Navigation begin
  $bEof = $next_record;
  if($bEof || $iPage != 1)
  {
    if ($iPage == 1) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font>
<? }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormRecommendedLessons_Page=1#RecommendedLessons"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></a>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormRecommendedLessons_Page=<?=$iPage - 1?>#RecommendedLessons"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font></a>
<?
    }
    echo "&nbsp;[&nbsp;" . $iPage . " of " . $iTotalPages . "&nbsp;]&nbsp;";
    
    if (!$bEof) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font>
<?
    }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormRecommendedLessons_Page=<?=$iPage + 1?>#RecommendedLessons"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font></a>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormRecommendedLessons_Page=last#RecommendedLessons"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></font></a>
<?
    }
  }

//-------------------------------
// RecommendedLessons Navigation end
//-------------------------------

//-------------------------------
// Finish form processing
//-------------------------------
  ?>
      </font></td></tr>
    </table>
  <?


//-------------------------------
// RecommendedLessons Close Event begin
// RecommendedLessons Close Event end
//-------------------------------
}
//===============================


//===============================
// Display Grid Form
//-------------------------------
function Categories_show()
{
//-------------------------------
// Initialize variables  
//-------------------------------
  
  
  global $db;
  global $sCategoriesErr;
  global $sFileName;
  global $styles;
  $sWhere = "";
  $sOrder = "";
  $sSQL = "";
  $sFormTitle = "Tutorial Lesson Categories";
  $HasParam = false;
  $iRecordsPerPage = 20;
  $iCounter = 0;

  $transit_params = "";
  $form_params = "";

//-------------------------------
// HTML column headers
//-------------------------------
?>
     <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="1"><a name="Categories"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
      </tr>
      <tr>
       <td style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"></td>
      </tr>
<?




//-------------------------------
// Build base SQL statement
//-------------------------------
  $sSQL = "select c.category_id as c_category_id, " . 
    "c.name as c_name " . 
    " from categories c ";
//-------------------------------

//-------------------------------
// Categories Open Event begin
// Categories Open Event end
//-------------------------------

//-------------------------------
// Assemble full SQL statement
//-------------------------------
  $sSQL .= $sWhere . $sOrder;
//-------------------------------

  

//-------------------------------
// Execute SQL statement
//-------------------------------
  $db->query($sSQL);
  $next_record = $db->next_record();
//-------------------------------
// Process empty recordset
//-------------------------------
  if(!$next_record)
  {
?>
     <tr>
      <td colspan="1" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">No records</font></td>
     </tr>
<?
   
?>
  </table>
<?

    return;
  }

//-------------------------------

//-------------------------------
// Initialize page counter and records per page
//-------------------------------
  $iRecordsPerPage = 20;
  $iCounter = 0;
//-------------------------------

//-------------------------------
// Display grid based on recordset
//-------------------------------
  while($next_record  && $iCounter < $iRecordsPerPage)
  {
//-------------------------------
// Create field variables based on database fields
//-------------------------------
    $fldname_URLLink = "TutorialLesson.php";
    $fldname_category_id = $db->f("c_category_id");
    $fldname = $db->f("c_name");
    $next_record = $db->next_record();
    
//-------------------------------
// Categories Show begin
//-------------------------------

//-------------------------------
// Categories Show Event begin
// Categories Show Event end
//-------------------------------


//-------------------------------
// Process the HTML controls
//-------------------------------
?>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"><a href="<?=$fldname_URLLink?>?category_id=<?=$fldname_category_id?>&<?= $transit_params ?>"><font style="font-size: 11px; color: #000000"><?=$fldname?></font></a>&nbsp;</font></td>
      </tr><?
//-------------------------------
// Categories Show end
//-------------------------------

//-------------------------------
// Move to the next record and increase record counter
//-------------------------------
    
    $iCounter++;
  }

 

//-------------------------------
// Finish form processing
//-------------------------------
  ?>
    </table>
  <?


//-------------------------------
// Categories Close Event begin
// Categories Close Event end
//-------------------------------
}
//===============================

?>