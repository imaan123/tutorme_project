<?php
/*********************************************************************************
 *       Filename: MembersRecord.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// MembersRecord CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// MembersRecord CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "MembersRecord.php";
//===============================


//===============================
// MembersRecord PageSecurity begin
check_security(2);
// MembersRecord PageSecurity end
//===============================

//===============================
// MembersRecord Open Event begin
// MembersRecord Open Event end
//===============================

//===============================
// MembersRecord OpenAnyPage Event start
// MembersRecord OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// MembersRecord Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sMembersErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Members":
    Members_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Members_show() ?>
    <SCRIPT Language="JavaScript">
if (document.forms["Members"])
document.Members.onsubmit=delconf;
function delconf() {
if (document.Members.FormAction.value == 'delete')
  return confirm('Delete record?');
}
</SCRIPT>
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// MembersRecord Show end

//===============================
// MembersRecord Close Event begin
// MembersRecord Close Event end
//===============================
//********************************************************************************


//===============================
// Action of the Record Form
//-------------------------------
function Members_action($sAction)
{
//-------------------------------
// Initialize variables  
//-------------------------------
  global $db;
  
  global $sForm;
  global $sMembersErr;
  global $styles;
  $bExecSQL = true;
  $sActionFileName = "";
  $sParams = "?";
  $sWhere = "";
  $bErr = false;
  $pPKmember_id = "";
  $fldmember_login = "";
  $fldmember_password = "";
  $fldmember_level = "";
  $fldname = "";
  $fldlast_name = "";
  $fldemail = "";
  $fldphone = "";
  $fldaddress = "";
  $fldnotes = "";
//-------------------------------

//-------------------------------
// Members Action begin
//-------------------------------
  $sActionFileName = "MembersGrid.php";
  $sParams .= "member_login=" . urlencode(get_param("Trn_member_login"));

//-------------------------------
// CANCEL action
//-------------------------------
  if($sAction == "cancel")
  {

//-------------------------------
// Members BeforeCancel Event begin
// Members BeforeCancel Event end
//-------------------------------
    header("Location: " . $sActionFileName . $sParams);
  }
//-------------------------------


//-------------------------------
// Build WHERE statement
//-------------------------------
  if($sAction == "update" || $sAction == "delete") 
  {
    $pPKmember_id = get_param("PK_member_id");
    if( !strlen($pPKmember_id)) return;
    $sWhere = "member_id=" . tosql($pPKmember_id, "Number");
  }
//-------------------------------


//-------------------------------
// Load all form fields into variables
//-------------------------------
  $fldmember_login = get_param("member_login");
  $fldmember_password = get_param("member_password");
  $fldmember_level = get_param("member_level");
  $fldname = get_param("name");
  $fldlast_name = get_param("last_name");
  $fldemail = get_param("email");
  $fldphone = get_param("phone");
  $fldaddress = get_param("address");
  $fldnotes = get_param("notes");

//-------------------------------
// Validate fields
//-------------------------------
  if($sAction == "insert" || $sAction == "update") 
  {
    if(!strlen($fldmember_login))
      $sMembersErr .= "The value in field Login* is required.<br>";
    
    if(!strlen($fldmember_password))
      $sMembersErr .= "The value in field Password* is required.<br>";
    
    if(!strlen($fldmember_level))
      $sMembersErr .= "The value in field Level* is required.<br>";
    
    if(!strlen($fldname))
      $sMembersErr .= "The value in field First Name* is required.<br>";
    
    if(!strlen($fldlast_name))
      $sMembersErr .= "The value in field Last Name* is required.<br>";
    
    if(!strlen($fldemail))
      $sMembersErr .= "The value in field Email* is required.<br>";
    
    if(!is_number($fldmember_level))
      $sMembersErr .= "The value in field Level* is incorrect.<br>";
    
    if(strlen($fldmember_login) )
    {
      $iCount = 0;

      if($sAction == "insert")
        $iCount = get_db_value("SELECT count(*) FROM members WHERE member_login=" . tosql($fldmember_login, "Text"));
      else if($sAction == "update")
        $iCount = get_db_value("SELECT count(*) FROM members WHERE member_login=" . tosql($fldmember_login, "Text") . " and not(" . $sWhere . ")");
      if($iCount > 0)
        $sMembersErr .= "The value in field Login* is already in database.<br>";
    }                                                                               
    
//-------------------------------
// Members Check Event begin
// Members Check Event end
//-------------------------------
    if(strlen($sMembersErr)) return;
  }
//-------------------------------


//-------------------------------
// Create SQL statement
//-------------------------------
  switch(strtolower($sAction)) 
  {
    case "insert":
//-------------------------------
// Members Insert Event begin
// Members Insert Event end
//-------------------------------
        $sSQL = "insert into members (" . 
          "member_login," . 
          "member_password," . 
          "member_level," . 
          "first_name," . 
          "last_name," . 
          "email," . 
          "phone," . 
          "address," . 
          "notes)" . 
          " values (" . 
          tosql($fldmember_login, "Text") . "," . 
          tosql($fldmember_password, "Text") . "," . 
          tosql($fldmember_level, "Number") . "," . 
          tosql($fldname, "Text") . "," . 
          tosql($fldlast_name, "Text") . "," . 
          tosql($fldemail, "Text") . "," . 
          tosql($fldphone, "Text") . "," . 
          tosql($fldaddress, "Text") . "," . 
          tosql($fldnotes, "Text") . 
          ")";
    break;
    case "update":

//-------------------------------
// Members Update Event begin
// Members Update Event end
//-------------------------------
        $sSQL = "update members set " .
          "member_login=" . tosql($fldmember_login, "Text") .
          ",member_password=" . tosql($fldmember_password, "Text") .
          ",member_level=" . tosql($fldmember_level, "Number") .
          ",first_name=" . tosql($fldname, "Text") .
          ",last_name=" . tosql($fldlast_name, "Text") .
          ",email=" . tosql($fldemail, "Text") .
          ",phone=" . tosql($fldphone, "Text") .
          ",address=" . tosql($fldaddress, "Text") .
          ",notes=" . tosql($fldnotes, "Text");
        $sSQL .= " where " . $sWhere;
    break;
    case "delete":
//-------------------------------
// Members Delete Event begin
// Members Delete Event end
//-------------------------------
        $sSQL = "delete from members where " . $sWhere;
    break;
  }
//-------------------------------
//-------------------------------
// Members BeforeExecute Event begin
// Members BeforeExecute Event end
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  if(strlen($sMembersErr)) return;
  if($bExecSQL)
    $db->query($sSQL);
  header("Location: " . $sActionFileName . $sParams);

//-------------------------------
// Members Action end
//-------------------------------
}

//===============================
// Display Record Form
//-------------------------------
function Members_show()
{
  global $db;
  
  global $sAction;
  global $sForm;
  global $sFileName;
  global $sMembersErr;
  global $styles;
  
  $fldmember_id = "";
  $fldmember_login = "";
  $fldmember_password = "";
  $fldmember_level = "";
  $fldname = "";
  $fldlast_name = "";
  $fldemail = "";
  $fldphone = "";
  $fldaddress = "";
  $fldnotes = "";
//-------------------------------
// Members Show begin
//-------------------------------
  $sFormTitle = "Intelligent Tutoring System - Members";
  $sWhere = "";
  $bPK = true;

?>
   
   <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
   <form method="POST" action="<?= $sFileName ?>" name="Members">
   <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
   <? if ($sMembersErr) { ?>
		<tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;" colspan="2"><font style="font-size: 11px; color: #000000"><?= $sMembersErr ?></font></td></tr>
	 <? } ?>
<? 

//-------------------------------
// Load primary key and form parameters
//-------------------------------
  if($sMembersErr == "")
  {
    $fldmember_login = get_param("member_login");
    $fldmember_id = get_param("member_id");
    $trn_member_login = get_param("member_login");
    $pmember_id = get_param("member_id");
  }
  else
  {
    $fldmember_id = strip(get_param("member_id"));
    $fldmember_login = strip(get_param("member_login"));
    $fldmember_password = strip(get_param("member_password"));
    $fldmember_level = strip(get_param("member_level"));
    $fldname = strip(get_param("name"));
    $fldlast_name = strip(get_param("last_name"));
    $fldemail = strip(get_param("email"));
    $fldphone = strip(get_param("phone"));
    $fldaddress = strip(get_param("address"));
    $fldnotes = strip(get_param("notes"));
    $trn_member_login = get_param("Trn_member_login");
    $pmember_id = get_param("PK_member_id");
  }
//-------------------------------

//-------------------------------
// Load all form fields

//-------------------------------

//-------------------------------
// Build WHERE statement
//-------------------------------
  
  if( !strlen($pmember_id)) $bPK = false;
  
  $sWhere .= "member_id=" . tosql($pmember_id, "Number");
//-------------------------------
//-------------------------------
// Members Open Event begin
// Members Open Event end
//-------------------------------

//-------------------------------
// Build SQL statement and execute query
//-------------------------------
  $sSQL = "select * from members where " . $sWhere;
  // Execute SQL statement
  $db->query($sSQL);
  $bIsUpdateMode = ($bPK && !($sAction == "insert" && $sForm == "Members") && $db->next_record());
//-------------------------------

//-------------------------------
// Load all fields into variables from recordset or input parameters
//-------------------------------
  if($bIsUpdateMode)
  {
    $fldmember_id = $db->f("member_id");
//-------------------------------
// Load data from recordset when form displayed first time
//-------------------------------
    if($sMembersErr == "") 
    {
      $fldmember_login = $db->f("member_login");
      $fldmember_password = $db->f("member_password");
      $fldmember_level = $db->f("member_level");
      $fldname = $db->f("first_name");
      $fldlast_name = $db->f("last_name");
      $fldemail = $db->f("email");
      $fldphone = $db->f("phone");
      $fldaddress = $db->f("address");
      $fldnotes = $db->f("notes");
    }
//-------------------------------
// Members ShowEdit Event begin
// Members ShowEdit Event end
//-------------------------------
  }
  else
  {
    if($sMembersErr == "")
    {
      $fldmember_id = tohtml(get_param("member_id"));
      $fldmember_login = tohtml(get_param("member_login"));
    }
//-------------------------------
// Members ShowInsert Event begin
// Members ShowInsert Event end
//-------------------------------
  }
//-------------------------------
// Members Show Event begin
// Members Show Event end
//-------------------------------

//-------------------------------
// Show form field
//-------------------------------
    ?>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Login*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="member_login" maxlength="20" value="<?= tohtml($fldmember_login) ?>" size="20" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Password*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="password" name="member_password" maxlength="20" value="<?= tohtml($fldmember_password) ?>" size="20" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Level*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><select size="1" name="member_level">
<?
    $LOV = split(";", "1;Member;2;Administrator");
  
    if(sizeof($LOV)%2 != 0) 
      $array_length = sizeof($LOV) - 1;
    else
      $array_length = sizeof($LOV);
    
    for($i = 0; $i < $array_length; $i = $i + 2)
    {
      if($LOV[$i] == $fldmember_level) 
        $option="<option SELECTED value=\"" . $LOV[$i] . "\">" . $LOV[$i + 1];
      else
        $option="<option value=\"" . $LOV[$i] . "\">" . $LOV[$i + 1];

      echo $option;
    }
?></select></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">First Name*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="name" maxlength="50" value="<?= tohtml($fldname) ?>" size="50" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Last Name*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="last_name" maxlength="50" value="<?= tohtml($fldlast_name) ?>" size="50" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Email*</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="email" maxlength="50" value="<?= tohtml($fldemail) ?>" size="50" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Phone</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="phone" maxlength="50" value="<?= tohtml($fldphone) ?>" size="50" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Address</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><input type="text" name="address" maxlength="50" value="<?= tohtml($fldaddress) ?>" size="50" ></font>
       </td>
     </tr>
      <tr>
       <td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;">
         <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Notes</font>
       </td>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;">
         <font style="font-size: 11px; color: #000000"><textarea name="notes" cols="50" rows="5"><?=tohtml($fldnotes)?></textarea></font>
       </td>
     </tr>
    <tr><td colspan="2" align="right">
<? if (!$bIsUpdateMode) { ?>
   <input type="hidden" value="insert" name="FormAction">
   <input type="submit" value="Insert" onclick="document.Members.FormAction.value = 'insert';">
<? } ?>
<? if ($bIsUpdateMode) { ?>
  <input type="hidden" value="update" name="FormAction"/>
  <input type="submit" value="Update" onclick="document.Members.FormAction.value = 'update';">
  <input type="submit" value="Delete" onclick="document.Members.FormAction.value = 'delete';">
<? } ?>
  <input type="submit" value="Cancel" onclick="document.Members.FormAction.value = 'cancel';">
  <input type="hidden" name="FormName" value="Members">
  
  <input type="hidden" name="Trn_member_login" value="<?= $trn_member_login ?>">
  <input type="hidden" name="PK_member_id" value="<?= $pmember_id ?>">  
  <input type="hidden" name="member_id" value="<?= tohtml($fldmember_id)?>">
  </td></tr>
  </form>
  </table>
<?
  


//-------------------------------
// Members Close Event begin
// Members Close Event end
//-------------------------------

//-------------------------------
// Members Show end
//-------------------------------
}
//===============================
?>