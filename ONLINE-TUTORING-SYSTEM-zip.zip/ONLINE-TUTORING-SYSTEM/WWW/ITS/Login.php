<?php
/*********************************************************************************
 *       Filename: Login.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// Login CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// Login CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "Login.php";
//===============================


//===============================
// Login PageSecurity begin
// Login PageSecurity end
//===============================

//===============================
// Login Open Event begin
// Login Open Event end
//===============================

//===============================
// Login OpenAnyPage Event start
// Login OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// Login Show begin

//===============================
// Perform the form's action
//-------------------------------
// Initialize error variables
//-------------------------------
$sLoginErr = "";

//-------------------------------
// Select the FormAction
//-------------------------------
switch ($sForm) {
  case "Login":
    Login_action($sAction);
  break;
}
//===============================

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>
<center>
 <table>
  <tr>
   
   <td valign="top">
<?php Login_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// Login Show end

//===============================
// Login Close Event begin
// Login Close Event end
//===============================
//********************************************************************************


//===============================
// Login Form Action
//-------------------------------
function Login_action($sAction)
{
  global $db;
  
  global $sLoginErr;
  global $sFileName;
  global $styles;

  switch(strtolower($sAction))
  {
    case "login":

//-------------------------------
// Login Login begin
//-------------------------------
      $sLogin = get_param("Login");
      $sPassword = get_param("Password");
      $db->query("SELECT member_id,member_level FROM members WHERE member_login =" . tosql($sLogin, "Text") . " AND member_password=" . tosql($sPassword, "Text"));
      $is_passed = $db->next_record();

//-------------------------------
// Login OnLogin Event begin
// Login OnLogin Event end
//-------------------------------
      if($is_passed)
      {
//-------------------------------
// Login and password passed
//-------------------------------
        set_session("UserID", $db->f("member_id"));
        set_session("UserRights", $db->f("member_level"));
        $sPage = get_param("ret_page");
        if (strlen($sPage))
          header("Location: " . $sPage);
        else
          header("Location: .php");
      }
      else
      {
        $sLoginErr = "Login or Password is incorrect.";
      }
//-------------------------------
// Login Login end
//-------------------------------
    break;
    case "logout":
//-------------------------------
// Logout action
//-------------------------------
//-------------------------------
// Login Logout begin
//-------------------------------

//-------------------------------
// Login OnLogout Event begin
// Login OnLogout Event end
//-------------------------------
      session_unregister("UserID");
      session_unregister("UserRights");
      if(strlen(get_param("ret_page")))
        header("Location:" . $sFileName . "?ret_page=" . urlencode(get_param("ret_page")));
      else
        header("Location:" . $sFileName);
//-------------------------------
// Login Logout end
//-------------------------------
    break;
  }
}
//===============================


//===============================
// Display Login Form
//-------------------------------
function Login_show()
{
  
  global $sLoginErr;
  global $db;
  global $sFileName;
  global $styles;
  $querystring =  get_param("querystring");
  $ret_page = get_param("ret_page");

  $sFormTitle = "Enter login and password";

//-------------------------------
// Login Show begin
//-------------------------------

//-------------------------------
// Login Open Event begin
// Login Open Event end
//-------------------------------

  ?>
    <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
    <form action="<?= $sFileName ?>" method="POST">
    <input type="hidden" name="FormName" value="Login">

    <tr><td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="2"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></td></tr>
    <? if ($sLoginErr) { ?>
    <tr><td colspan="2" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"><?= $sLoginErr ?></font></td></tr>
    <? } ?>

  <?

  if(get_session("UserID") == "") 
  {
//-------------------------------
//- User is not logged in
//-------------------------------
?>
      <tr><td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Login</font></td><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><input type="text" name="Login" value="<?=tohtml(get_param("Login"))?>" maxlength="50"></td></tr>
      <tr><td style="background-color: #F7F3EF; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Password</font></td><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><input type="password" name="Password" maxlength="50"></td></tr>
      <tr><td colspan="2">
      <input type="hidden" name="FormAction" value="login">
      <input type="submit" value="Login">
      </td></tr>
    <?
  }
  else
  {
//-------------------------------
// User is logged in
//-------------------------------
    $db->query("SELECT member_login FROM members WHERE member_id=". get_session("UserID"));
    $db->next_record();
?>
      <tr><td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"> <?= $db->f("member_login") ?></font>
      <input type="hidden" name="FormAction" value="logout">
      <input type="submit" value="Logout">
      </td></tr>
<?
  }
?>
  <input type="hidden" name="ret_page" value="<?= $ret_page ?>"><input type="hidden" name="querystring" value="<?= $querystring ?>"></td></tr>
  </form></table>
<?

//-------------------------------
// Login Close Event begin
// Login Close Event end
//-------------------------------

//-------------------------------
// Login Show end
//-------------------------------
}
//===============================


?>