<?php
/*********************************************************************************
 *       Filename: CategoriesGrid.php
 *       Intelligent Tutoring System (ITS)
 *       PHP 4.0 + MySQL + AJAX
 *********************************************************************************/

//-------------------------------
// CategoriesGrid CustomIncludes begin

include ("./common.php");
include ("./Header.php");
include ("./Footer.php");

// CategoriesGrid CustomIncludes end
//-------------------------------

session_start();

//===============================
// Save Page and File Name available into variables
//-------------------------------
$sFileName = "CategoriesGrid.php";
//===============================


//===============================
// CategoriesGrid PageSecurity begin
check_security(2);
// CategoriesGrid PageSecurity end
//===============================

//===============================
// CategoriesGrid Open Event begin
// CategoriesGrid Open Event end
//===============================

//===============================
// CategoriesGrid OpenAnyPage Event start
// CategoriesGrid OpenAnyPage Event end
//===============================

//===============================
//Save the name of the form and type of action into the variables
//-------------------------------
$sAction = get_param("FormAction");
$sForm = get_param("FormName");
//===============================

// CategoriesGrid Show begin

//===============================
// Display page

//===============================
// HTML Page layout
//-------------------------------
?><html>
<head>
<title>.:: Intelligent Tutoring System ::.</title>
<meta name="GENERATOR" content="Intelligent Tutoring System">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"></head>
<body style="background-color: #FFFFFF; color: #000000">
<center>
 <table>
  <tr>
   <td valign="top">
 <?php Menu_show() ?>
   
   </td>
  </tr>
 </table>

 <table>
  <tr>
   
   <td valign="top">
<?php Categories_show() ?>
    
   </td>
  </tr>
 </table>

<center>
 <table>
  <tr>
   <td valign="top">
<?php Footer_show() ?>
    </td>
   
  </tr>
 </table>
 </center>
</body>
</html>
<?php

// CategoriesGrid Show end

//===============================
// CategoriesGrid Close Event begin
// CategoriesGrid Close Event end
//===============================
//********************************************************************************


//===============================
// Display Grid Form
//-------------------------------
function Categories_show()
{
//-------------------------------
// Initialize variables  
//-------------------------------
  
  
  global $db;
  global $sCategoriesErr;
  global $sFileName;
  global $styles;
  $sWhere = "";
  $sOrder = "";
  $sSQL = "";
  $sFormTitle = "Categories";
  $HasParam = false;
  $iRecordsPerPage = 20;
  $iCounter = 0;
  $iPage = 0;
  $bEof = false;
  $iSort = "";
  $iSorted = "";
  $sDirection = "";
  $sSortParams = "";
  $sActionFileName = "CategoriesRecord.php";

  $transit_params = "";
  $form_params = "";

//-------------------------------
// Build ORDER BY statement
//-------------------------------
  $sOrder = " order by c.name Asc";
  $iSort = get_param("FormCategories_Sorting");
  $iSorted = get_param("FormCategories_Sorted");
  if(!$iSort)
  {
    $form_sorting = "";
  }
  else
  {
    if($iSort == $iSorted)
    {
      $form_sorting = "";
      $sDirection = " DESC";
      $sSortParams = "FormCategories_Sorting=" . $iSort . "&FormCategories_Sorted=" . $iSort . "&";
    }
    else
    {
      $form_sorting = $iSort;
      $sDirection = " ASC";
      $sSortParams = "FormCategories_Sorting=" . $iSort . "&FormCategories_Sorted=" . "&";
    }
    if ($iSort == 1) $sOrder = " order by c.name" . $sDirection;
  }

//-------------------------------
// HTML column headers
//-------------------------------
?>
     <table style="background-color: #D6D3CE; border-bottom: 1px solid #848284; border-right: 1px solid #848284; border-top: 1px solid #ffffff;  border-left: 1px solid #ffffff;">
      <tr>
       <td style="background-color: #000084; text-align: center; border-top: 1px solid #D6D3CE;  border-left: 1px solid #D6D3CE; border-right: 1px solid #D6D3CE; border-bottom: 1px solid #D6D3CE;" colspan="1"><a name="Categories"><font style="font-size: 11px; color: #FFFFFF; font-weight: bold; font-family: Tahoma, Verdana, Arial, Helvetica;"><?=$sFormTitle?></font></a></td>
      </tr>
      <tr>
       <td style="background-color: #D6D3CE;"><a href="<?=$sFileName?>?<?=$form_params?>FormCategories_Sorting=1&FormCategories_Sorted=<?=$form_sorting?>&"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Name</font></a></td>
      </tr>
<?




//-------------------------------
// Build base SQL statement
//-------------------------------
  $sSQL = "select c.category_id as c_category_id, " . 
    "c.name as c_name " . 
    " from categories c ";
//-------------------------------

//-------------------------------
// Categories Open Event begin
// Categories Open Event end
//-------------------------------

//-------------------------------
// Assemble full SQL statement
//-------------------------------
  $sSQL .= $sWhere . $sOrder;
//-------------------------------

  

//-------------------------------
// Process the link to the record page
//-------------------------------
  $form_action = $sActionFileName;
//-------------------------------

//-------------------------------
// Execute SQL statement
//-------------------------------
  $db->query($sSQL);
  $next_record = $db->next_record();
//-------------------------------
// Process empty recordset
//-------------------------------
  if(!$next_record)
  {
?>
     <tr>
      <td colspan="1" style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000">No records</font></td>
     </tr>
<?
 
//-------------------------------
//  The insert link.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $form_action ?>?<?= $transit_params ?>"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Insert</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?  
?>
  </table>
<?

    return;
  }

//-------------------------------

//-------------------------------
// Initialize page counter and records per page
//-------------------------------
  $iRecordsPerPage = 20;
  $iCounter = 0;
//-------------------------------

//-------------------------------
// Process page scroller
//-------------------------------
  $iPage = get_param("FormCategories_Page");
  if(!strlen($iPage)) $iPage = 1; else $iPage = intval($iPage);

  if(($iPage - 1) * $iRecordsPerPage != 0)
  {
    do
    {
      $iCounter++;
    } while ($iCounter < ($iPage - 1) * $iRecordsPerPage && $db->next_record());
    $next_record = $db->next_record();
  }

  $iCounter = 0;
//-------------------------------

//-------------------------------
// Display grid based on recordset
//-------------------------------
  while($next_record  && $iCounter < $iRecordsPerPage)
  {
//-------------------------------
// Create field variables based on database fields
//-------------------------------
    $fldname_URLLink = "CategoriesRecord.php";
    $fldname_category_id = $db->f("c_category_id");
    $fldname = $db->f("c_name");
    $next_record = $db->next_record();
    
//-------------------------------
// Categories Show begin
//-------------------------------

//-------------------------------
// Categories Show Event begin
// Categories Show Event end
//-------------------------------


//-------------------------------
// Process the HTML controls
//-------------------------------
?>
      <tr>
       <td style="background-color: #ffffff; border-left: 1px solid #848284; border-top: 1px solid #848284; border-bottom: 1px solid #E7E7E7; border-right: 1px solid #E7E7E7; font-family: Tahoma, Verdana, Arial, Helvetica;"><font style="font-size: 11px; color: #000000"><a href="<?=$fldname_URLLink?>?category_id=<?=$fldname_category_id?>&<?= $transit_params ?>"><font style="font-size: 11px; color: #000000"><?=$fldname?></font></a>&nbsp;</font></td>
      </tr><?
//-------------------------------
// Categories Show end
//-------------------------------

//-------------------------------
// Move to the next record and increase record counter
//-------------------------------
    
    $iCounter++;
  }

 
//-------------------------------
//  Grid. The insert link and record navigator.
//-------------------------------
?>
    <tr>
     <td colspan="1" style="background-color: #D6D3CE;"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;"><a href="<?= $form_action ?>?<?= $transit_params ?>"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Insert</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?
  // Categories Navigation begin
  $bEof = $next_record;
  if($bEof || $iPage != 1)
  {
    if ($iPage == 1) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font>
<? }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormCategories_Page=<?=$iPage - 1?>#Categories"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Previous</font></a>
<?
    }
    echo "&nbsp;[&nbsp;" . $iPage . "&nbsp;]&nbsp;";
    
    if (!$bEof) {
?>
        <font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font>
<?
    }
    else {
?>
        <a href="<?=$sFileName?>?<?=$form_params?><?=$sSortParams?>FormCategories_Page=<?=$iPage + 1?>#Categories"><font style="font-size: 11px; color: #000000; font-family: Tahoma, Verdana, Arial, Helvetica;">Next</font></a>
<?
    }
  }

//-------------------------------
// Categories Navigation end
//-------------------------------

//-------------------------------
// Finish form processing
//-------------------------------
  ?>
      </font></td></tr>
    </table>
  <?


//-------------------------------
// Categories Close Event begin
// Categories Close Event end
//-------------------------------
}
//===============================

?>