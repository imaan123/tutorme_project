# phpMyAdmin SQL Dump
# version 2.5.7-pl1
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Jan 21, 2006 at 12:57 PM
# Server version: 4.0.21
# PHP Version: 5.0.1
# 
# Database : `ITS`
# 

# --------------------------------------------------------

#
# Table structure for table `MEMBERS`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 21, 2006 at 04:13 AM
#

DROP TABLE IF EXISTS `MEMBERS`;
CREATE TABLE `MEMBERS` (
  `member_id` int(11) NOT NULL auto_increment,
  `member_login` varchar(20) NOT NULL default '',
  `member_password` varchar(20) NOT NULL default '',
  `member_level` int(11) NOT NULL default '1',
  `first_name` varchar(50) NOT NULL default '',
  `last_name` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `phone` varchar(50) default NULL,
  `address` varchar(50) default NULL,
  `notes` text,
  `card_type_id` int(11) default NULL,
  `card_number` varchar(50) default NULL,
  PRIMARY KEY  (`member_id`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

#
# Dumping data for table `MEMBERS`
#

INSERT DELAYED INTO `MEMBERS` (`member_id`, `member_login`, `member_password`, `member_level`, `first_name`, `last_name`, `email`, `phone`, `address`, `notes`, `card_type_id`, `card_number`) VALUES (1, 'admin', 'admin', 2, 'Administrator', 'Account', 'admin@localhost', NULL, NULL, NULL, NULL, NULL),
(2, 'guest', 'guest', 1, 'Guest', 'Account', 'guest@localhost', NULL, NULL, NULL, NULL, NULL);

# --------------------------------------------------------

#
# Table structure for table `ORDERS`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 20, 2006 at 08:07 PM
#

DROP TABLE IF EXISTS `ORDERS`;
CREATE TABLE `ORDERS` (
  `order_id` int(11) NOT NULL auto_increment,
  `member_id` int(11) NOT NULL default '0',
  `item_id` int(11) NOT NULL default '0',
  `quantity` int(11) NOT NULL default '0',
  PRIMARY KEY  (`order_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

#
# Dumping data for table `ORDERS`
#


# --------------------------------------------------------

#
# Table structure for table `card_types`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 20, 2006 at 08:12 PM
#

DROP TABLE IF EXISTS `card_types`;
CREATE TABLE `card_types` (
  `card_type_id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`card_type_id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `card_types`
#

INSERT DELAYED INTO `card_types` (`card_type_id`, `name`) VALUES (1, 'Visa'),
(2, 'American Express');

# --------------------------------------------------------

#
# Table structure for table `categories`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 20, 2006 at 10:30 PM
#

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`category_id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

#
# Dumping data for table `categories`
#

INSERT DELAYED INTO `categories` (`category_id`, `name`) VALUES (1, 'Chapter 1'),
(2, 'Chapter 2'),
(3, 'Chapter 3');

# --------------------------------------------------------

#
# Table structure for table `editorial_categories`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 20, 2006 at 08:12 PM
#

DROP TABLE IF EXISTS `editorial_categories`;
CREATE TABLE `editorial_categories` (
  `editorial_cat_id` int(11) NOT NULL auto_increment,
  `editorial_cat_name` varchar(50) default NULL,
  PRIMARY KEY  (`editorial_cat_id`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

#
# Dumping data for table `editorial_categories`
#

INSERT DELAYED INTO `editorial_categories` (`editorial_cat_id`, `editorial_cat_name`) VALUES (1, 'What'),
(2, 'New'),
(3, 'Weekly'),
(4, 'General');

# --------------------------------------------------------

#
# Table structure for table `editorials`
#
# Creation: Jan 20, 2006 at 04:07 AM
# Last update: Jan 20, 2006 at 08:12 PM
#

DROP TABLE IF EXISTS `editorials`;
CREATE TABLE `editorials` (
  `article_id` int(11) NOT NULL auto_increment,
  `editorial_cat_id` int(11) default '0',
  `article_title` varchar(200) default NULL,
  `article_desc` text,
  `item_id` int(11) default '0',
  PRIMARY KEY  (`article_id`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

#
# Dumping data for table `editorials`
#

INSERT DELAYED INTO `editorials` (`article_id`, `editorial_cat_id`, `article_title`, `article_desc`, `item_id`) VALUES (1, 1, 'A Sharp Combination', 'To get inside C#, Microsoft\'s new OO programming language, use A Preview of C# as a guide. It offers a preview of Visual Studio.NET and an overview of the .NET framework, and demonstrates how C# is integrated with ASP+, ADO+, and COM+ in .NET applications. You\'ll get examples of C# in action, too.', 22),
(2, 2, '1001 Web Site Construction Tips and Tricks', '39.95', 21),
(3, 3, 'Flash 4 Magic', 'If you\'re right in the middle of learning (or just jumping into) Flash to create and manipulate animations, music tracks, sound effects, and interface design, try the Flash 4 Magic. Inside are tutorials, graphic presentations, and a CD.', 8),
(4, 4, '<b><font color="brown">Free Shipping on orders over $40</font></b>', 'For limited time only, until next Sunday, you can enjoy free shipping. Simply order more then $40 worth of books and shipping\'s on us.', 0);

# --------------------------------------------------------

#
# Table structure for table `items`
#
# Creation: Jan 21, 2006 at 01:41 AM
# Last update: Jan 21, 2006 at 12:49 PM
#

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL auto_increment,
  `category_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `author` varchar(100) default NULL,
  `price` float NOT NULL default '0',
  `product_url` varchar(255) default NULL,
  `image_url` varchar(100) default NULL,
  `notes` text,
  `is_recommended` tinyint(4) default '0',
  `rating` int(11) default '0',
  `rating_count` int(11) default '0',
  `ai` varchar(255) default NULL,
  `quiz` varchar(255) default NULL,
  PRIMARY KEY  (`item_id`)
) TYPE=MyISAM AUTO_INCREMENT=26 ;

#
# Dumping data for table `items`
#

INSERT DELAYED INTO `items` (`item_id`, `category_id`, `name`, `author`, `price`, `product_url`, `image_url`, `notes`, `is_recommended`, `rating`, `rating_count`, `ai`, `quiz`) VALUES (6, 1, 'English Grammar', 'Chapter 1 - Lesson 1', '23.99', 'images/books/lesson.gif', 'images/books/chapter1lesson1.jpg', 'If you think you have difficulties understanding this lessons just Activate the Online Virtual Professor.', 1, 0, 0, 'ai/lesson1', 'quiz/lesson1'),
(8, 1, 'Engish Spelling', 'Chapter 1 - Lesson 2', '36', 'images/books/lesson.gif', 'images/books/chapter1lesson2.jpg', 'If you think you have difficulties understanding this lessons just Activate the Online Virtual Professor.', 1, 0, 0, 'ai/lesson2', 'quiz/lesson2'),
(9, 2, 'Mathematics - Addition', 'Chapter 2 - Lesson 1', '36', 'images/books/lesson.gif', 'images/books/chapter2lesson1.jpg', 'If you think you have difficulties understanding this lessons just Activate the Online Virtual Professor.', 1, 0, 0, 'ai/lesson3', 'quiz/lesson3'),
(10, 2, 'Mathematics - Subtraction', 'Chapter 2 - Lesson 2', '39.99', 'images/books/lesson.gif', 'images/books/chapter2lesson2.jpg', 'If you think you have difficulties understanding this lessons just Activate the Online Virtual Professor.', 1, 0, 0, 'ai/lesson4', 'quiz/lesson4'),
(11, 3, 'Science - Earth and Space', 'Chapter 3 - Lesson 1', '41.99', 'images/books/lesson.gif', 'images/books/chapter3lesson1.jpg', 'If you think you have difficulties understanding this lessons just Activate the Online Virtual Professor.', 1, 0, 0, 'ai/lesson5', 'quiz/lesson5');
